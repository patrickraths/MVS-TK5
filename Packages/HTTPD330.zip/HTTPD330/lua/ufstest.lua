-- Lua - ufstest.lua
-- require'http'

http.print("Hello from ufstest.lua")
