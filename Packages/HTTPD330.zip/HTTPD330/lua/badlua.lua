-- Lua - badlua to cause a failure
print nothing
