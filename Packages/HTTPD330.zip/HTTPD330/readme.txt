What is HTTPD?

HTTPD is a web page server that runs on legacy MVS.38J operating system in a Hercules emulator environment.
HTTPD can serve both static and dynamic web pages to web browsers like Chrome, FireFox, Edge, etc.
HTTPD can use both Partition Data Sets (PDS) as well as a Unix "like" File System (UFS).
Dynamic web pages can be created using REXX (HTTPREXX) or Lua (HTTPLUA) scripting, or custom C program (HTTPJES2).

How can I install HTTPD on my MVS.38J system?

First you'll need an appropriate HTTPD release built as a transmit file (.XMIT extension) 
that you can upload to your MVS system using a TN3270 type terminal emulator and the IND$FILE
file transfer program. Most TN3270 emulators will have file transfer built in that envokes
the TSO IND$FILE trafer program at the TSO READY prompt.

Next you'll need the INSTALL.JCL file which can be found in the ZIP file and also in the XMIT file.
You must chnage the 'YOUR UPLOAD DATASET' in the INSTALL.JCL file to the name of the dataset
on your MVS.38J TSO that you uploaded in the first step.

Submit the INSTALL.JCL file to run on your MVS.38J system. Various HTTPD datasets will be created
or updated on your MVS.38J system.

Okay, I installed HTTPD using INSTALL.JCL, how to I make it run?

In the ZIP file (new install) or in SYS2.PROCLIB (update/upgrade of HTTPD) you will need the HTTPD PROC
saved into the SYS2.PROCLIB dataset. You should review the HTTPD PROC member and adjust dataset names
as needed for your system.

Once you have HTTPD PROC in SYS2.PROCLIB you can enter /S HTTPD on the system console to start HTTPD.

An alternate method is to run HTTPD as a batch job. See the HTTPD.JCL in the zip file. Just submit
the job after making any changes for your MVS.38J operating system.

Okay, I have HTTPD running, how do I shut it down?

On the MVS.38J console enter the stop command: /P HTTPD

Okay, I can start and stop HTTPD. How do I browse the HTTPD web server?

You'll need a web browser like Chrome, FireFox, Edge, etc. In the URL of the web browser you need to
enter the host name or IP address as well as the port number that HTTPD is listening on.
Assuming you are using the HTTPD server defaults and your Hercules emulator that runs MVS.38J is
on the same machine as your web browser, you would enter "http://127.0.0.1:8080/" which should
return the default web page "index.html". Note: "127.0.0.1" is the local loop back network adapter
of your local machine.  If Hercules is on another machine you would use that machines IP address
or network name (from your DNS).

Can I have HTTPD listen on port 80 (the default HTTP protocol port)?

Maybe. It depends on the host machine running Hercules. This issue is that most machines treat
port number that are less than 1024 as being reserved for system use and/or administrator
assigned use. Generally this means non-priveledged applications are not allowed to use the
first 1023 port numbers. You would also have to make sure no other HTTP server is using that
port number on the machine that is hosting Hercules.

I like HTTPD, can I run it on z/OS or some other MVS platform?

Probably not. HTTPD was designed knowing that it was to run in a Hercules and MVS.38J environment.
Legacy MVS.38J didn't have network sockets, but we have "host" sockets provided by Hercules using 
the DYN75 interface. And we violate a few security related issues using SVC 241 to dynamically
authorize HTTPD and the HTTPD STEPLIB datasets. You would need to make extensive code changes
to get HTTPD to run on a modern z/OS or MVS release.
If you try to run it on z/OS or outside of Hercules you can expect to get S0C1 and/or S0C4 ABENDs.

Where can I get more information?

Each release has a changelog file and should be reviewed as needed.

You'll also find a "docs" directory/folder in the zip file. You can view the "html" files
in the docs folder using your web browser. The 'index.html" file is the best place to start.

I don't want HTTPD to use SVC 241 to become APF authorized. What do I need to do?

Update your IEAAPF00 member in SYS1.PARMLIB dataset.

Example IEAAPF00:
 SYS1.VTAMLIB MVSRES,      
 HTTPD.LINKLIB xxxxxx 
Be sure to replace the xxxxxx with the actual volser for the HTTPD.LINKLIB dataset and reboot TK5 to activate the change.

How do I access the JES2 spool queue using HTTPD?

To access the JES spool via the HTTPD server you should use your web browser with a url like 
http://127.0.0.1:8080/jesst.html

Once you have a JES Status page displayed you should be able to right-click on the table rows and get a context menu for the job on that table row.  The context menu has options for:
Display DD List
Download To File
View in Browser
Cancel jobname jobid
Purge jobname jobid

Are there any operator commands for HTTPD?

Operator Commands:
/P HTTPD (or whatever your HTTPD STC or jobname is) will terminate the HTTPD server.
/F HTTPD,D P display the listen ports used by the HTTPD server.
/F HTTPD,D T display task running in the HTTPD server.
/F HTTPD,HELP
/14.34.43 STC   95  HTTPD000I MODIFY commands are:                                                                     
/14.34.43 STC   95  HTTPD000I Display Login                                                                            
/14.34.43 STC   95  HTTPD000I     display users that are logged into the HTTPD server                                  
/14.34.43 STC   95  HTTPD000I Display Memory xxxxxx[,nnn] (D M xxxxxx)                                                 
/14.34.43 STC   95  HTTPD000I     displays memory at given address xxxxxx                                              
/14.34.43 STC   95  HTTPD000I Display Ports (D P)                                                                      
/14.34.43 STC   95  HTTPD000I     displays the port number this server is listening on.                                
/14.34.43 STC   95  HTTPD000I Display Stats n [Months|Days|Hours|Minutes|all]                                          
/14.34.43 STC   95  HTTPD000I     displays HTTPD client statistics.                                                    
/14.34.43 STC   95  HTTPD000I Display Threads (D T)                                                                    
/14.34.43 STC   95  HTTPD000I     displays information about the server threads.                                       
/14.34.43 STC   95  HTTPD000I Display TIme [-|+][tzoffset] (D TI)                                                      
/14.34.43 STC   95  HTTPD000I     displays current time in GMT and local time.                                         
/14.34.43 STC   95  HTTPD000I Display Version (D V)                                                                    
/14.34.43 STC   95  HTTPD000I     displays server version.                                                             
/14.34.43 STC   95  HTTPD000I                                                                                          
/14.34.43 STC   95  HTTPD000I Set Login [all,cgi,get,head,post,none] (S L ...)                                         
/14.34.43 STC   95  HTTPD000I     set the login option.                                                                
/14.34.43 STC   95  HTTPD000I Set MAxtask n (S MAxtask n)                                                              
/14.34.43 STC   95  HTTPD000I     set the worker maximum thread count.                                                 
/14.34.43 STC   95  HTTPD000I Set MIntask n (S MIntask n)                                                              
/14.34.43 STC   95  HTTPD000I     set the worker minimum thread count.                                                 
/14.34.43 STC   95  HTTPD000I Set Stats ON|OFF [Save|Clear|Free|Reset]                                                 
/14.34.43 STC   95  HTTPD000I     set client statistics recording ON or OFF.                                           
/14.34.43 STC   95  HTTPD000I                                                                                          
/14.34.43 STC   95  HTTPD000I Example: /F HTTPD,D P 
...

Sample output from the HTTPD server:
/14.35.53 STC   96  IEF403I HTTPD - STARTED - TIME=14.35.53                                                            
/14.35.53 STC   96  +HTTPD000I HTTPD Server 3.0.0 starting                                                             
/14.35.53 STC   96  HTTPD011I HTTPD was APF authorized via SVC 244                                                     
/14.35.53 STC   96  HTTPD013I STEPLIB is now APF authorized                                                            
/14.35.53 STC   96  HTTPD025I Time zone offset set to GMT +00:00:00                                                    
/14.35.53 STC   96  HTTPD048I Login not required for any request                                                       
/14.35.53 STC   96  HTTPD046I Disk#0 File System on DD UFSDISK0 READ/WRITE                                             
/14.35.53 STC   96  HTTPD032I Listening for HTTP request on port 8080                                                  
/14.35.53 STC   96  HTTPD001I Server is READY                                                                          
/14.35.53 STC   96  HTTPD061I STARTING socket thread  TCB(9ACA58) TASK(1D7FC8) MGR(1CB0A8) CRT(1E9DC8)                 
/14.35.53 STC   96  HTTPD061I STARTING worker(1E9B88) TCB(99F940) TASK(1EBFC8) MGR(1CB0A8) CRT(1E9800)                 
/14.35.53 STC   96  HTTPD061I STARTING worker(1E9A88) TCB(99F610) TASK(1FCFC8) MGR(1CB0A8) CRT(1E95F8)                 
/14.35.53 STC   96  HTTPD061I STARTING worker(1E9A08) TCB(99F2E0) TASK(20DFC8) MGR(1CB0A8) CRT(1E93F0)
...

/f httpd,d p                                                                                                           
/14.36.52 STC   96  HTTPD100I CONS(3) START                                                                            
/14.36.52 STC   96  HTTPD100I CONS(3) "D P"                                                                            
/14.36.52 STC   96  HTTPD102I HTTPD server listening on port 8080
...

/p httpd                                                                                                               
/14.37.58 STC   96  HTTPD100I CONS(3) STOP                                                                             
/14.37.58 STC   96  HTTPD002I Server is QUIESCE                                                                        
/14.37.58 STC   96  HTTPD060I SHUTDOWN socket thread  TCB(9ACA58) TASK(1D7FC8) MGR(1CB0A8) CRT(1E9DC8)                 
/14.37.59 STC   96  HTTPD060I SHUTDOWN worker(1E9A08) TCB(99F2E0) TASK(20DFC8) MGR(1CB0A8) CRT(1E93F0)                 
/14.37.59 STC   96  HTTPD060I SHUTDOWN worker(1E9A88) TCB(99F610) TASK(1FCFC8) MGR(1CB0A8) CRT(1E95F8)                 
/14.37.59 STC   96  HTTPD060I SHUTDOWN worker(1E9B88) TCB(99F940) TASK(1EBFC8) MGR(1CB0A8) CRT(1E9800)                 
/14.38.00 STC   96  HTTPD047I Terminating File System                                                                  
/14.38.00 STC   96  HTTPD002I Server is SHUTDOWN                                                                       
/14.38.00 STC   96  IEF404I HTTPD - ENDED - TIME=14.38.00                                                              
/14.38.00 STC   96  $HASP395 HTTPD    ENDED
...

