LBTUTOR for MVS3.8J / Hercules                                               
==============================                                               


Date: 11/15/2023  Release V0R9M01
      07/10/2023  Release V0R9M00  **INITIAL software distribution
      09/11/2019  Release V0R5M00

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/LBTUTOR-in-MVS38J
*           Copyright (C) 2019-2023  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    LBTUTOR      I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    LBTUTOR      C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  11/15/2023 0.9.01   - Isolated version of NCZ93205 by including            
*                        soource code as LBPDSIOM to prevent conflict
*                        with existing version of NCZ93205.
*                                                                               
*  07/10/2023 0.9.00   - Alpha version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*  06/01/2019 0.5.00   Initial prototyping and development                      
*                      w ISPF 2.x       
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  LBTUTOR.V0R9M01.HET  Hercules Emulated Tape (HET) multi-file volume
   volser=VS0901        containing software distribution library.

o  LBTUTOR.V0R9M01.XMI  XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.2+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   SHRABIT.MACLIB is macro library required to assemble/compile this
-----   software.  A version as-of this distribution is included for
        installation as a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/SHRABIT-MACLIB-in-MVS-3-8J/

Note:   DYNBLOAD is a subroutine to dynamically call programs
-----   from MVT COBOL and must be installed as a pre-requisite. 
        A version as-of this distribution is included for convenience.
        More information including current version download link at:
        https://www.shareabitofit.net/dynbload-in-mvs38j/

Credit: DYNBLOAD is a modified version of DYNALOAD authored  
------- by Ed Liss.  Thanks to Ed Liss for his subprogram.
        More information about DYNALOAD and may be downloaded in a
        MVS 3.8J install-ready format from Jay Moseley's site:
        https://www.jaymoseley.com/hercules/misc_pgms/miscpgms.htm#Dynaload

Note:   NCZ93205 (assembler subroutine) reads PDS members and is a
-----   pre-requisite for this install. For convenience purposes,
        NCZ93205 source is included under member name LBPDSIOM.
        This source is from Jay Moseley's web site.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #152 
                           (Harold Zbiegien Utilities)
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
   https://www.jaymoseley.com/hercules/misc_pgms/miscpgms.htm#AccessPDSMembers

Credit: CBT File#152 contributed by Harold Zbiegien Jan 1990
------- contains an updated version of NCZ93205. 
        CBT File#430 contains original (11/1982) donated version submitted 
        Smith International Ltd.
        Thanks to Smith International and Harold Abiegien for this
        CBT contribution.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #152, FILE#430 


======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.LBTUTOR.V0R9M01.ASM                  PUB006    25    12 PO  FB  48  1
   SHRABIT.LBTUTOR.V0R9M01.CLIST                PUB006    15     1 PO  FB   6  1
   SHRABIT.LBTUTOR.V0R9M01.CNTL                 PUB006    20     5 PO  FB  25  1
   SHRABIT.LBTUTOR.V0R9M01.HELP                 PUB006     4     1 PO  FB  25  1
   SHRABIT.LBTUTOR.V0R9M01.ISPF                 PUB006    20     4 PO  FB  20  1
   SHRABIT.LBTUTOR.V0R9M01.MACLIB               PUB006     6     3 PO  FB  50  1
   **END**    TOTALS:      90 TRKS ALLOC        26 TRKS USED       6 EXTENTS    


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($RECVXMI)         |
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($RECVTSO)         |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive LBTUTOR XMI',      <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 LBTUTOR Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(25,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(06,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for LBTUTOR software distribution    *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE LBTUTOR Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.LBTUTOR.V0R9M01.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(CNTL)') -  
        DA('SHRABIT.LBTUTOR.V0R9M01.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(HELP)') -  
        DA('SHRABIT.LBTUTOR.V0R9M01.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(CLIST)') -  
        DA('SHRABIT.LBTUTOR.V0R9M01.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(ISPF)') -  
        DA('SHRABIT.LBTUTOR.V0R9M01.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(ASM)') -  
        DA('SHRABIT.LBTUTOR.V0R9M01.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.LBTUTOR.V0R9M01.XMIPDS(MACLIB)') - 
        DA('SHRABIT.LBTUTOR.V0R9M01.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.LBTUTOR.V0R9M01.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer LBTUTOR.V0R9M01.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.LBTUTOR.V0R9M01.ASM
       SHRABIT.LBTUTOR,V0R9M01.CLIST
       SHRABIT.LBTUTOR,V0R9M01.CNTL
       SHRABIT.LBTUTOR,V0R9M01.HELP
       SHRABIT.LBTUTOR,V0R9M01.ISPF
       SHRABIT.LBTUTOR,V0R9M01.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ LBTUTOR in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST00)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR0 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST01)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR1 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=LBTUTOR,TVOLSER=VS0901,
//   HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\LBTUTOR.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST02)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR2 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=LBTUTOR,TVOLSER=VS0901,
//   HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(25,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(06,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\LBTUTOR.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($UP0901)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTORU JOB (SYS),'Upgrade LBTUTOR',      <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $UP0900  Upgrade LBTUTOR Software              *
//* *       Upgrade to release V0R9M01 from V0R9M00        *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: COBLKED                                       *
//* *       COBOL     Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//COBL     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT,
//             CPARM1='LOAD,SUPMAP',                                
//             CPARM2='SIZE=2048K,BUF=1024K'                        
//*COB EXEC  PGM=IKFCBL00,REGION=4096K,                             
//*          PARM='LOAD,SUPMAP,SIZE=2048K,BUF=1024K'                
//COB      EXEC PGM=IKFCBL00,REGION=4096K,                             
//           PARM='&CPARM1,&CPARM2'                                 
//STEPLIB  DD  DUMMY
//SYSPRINT DD  SYSOUT=*                                             
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT2   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT3   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT4   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(MOD,PASS),UNIT=SYSDA,             
//             SPACE=(80,(500,100))                                 
//SYSLIB   DD  DSN=&HLQ..&VRM..ASM,DISP=SHR
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='LIST,XREF,LET',
//             COND=(5,LT,COB),REGION=96K
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(OLD,DELETE)                      
//         DD  DDNAME=SYSIN                                                
//SYSLMOD  DD  DUMMY                                        
//SYSLIB   DD  DUMMY                  
//SYSUT1   DD  UNIT=SYSDA,SPACE=(1024,(50,20))                         
//SYSPRINT DD  SYSOUT=*                                              
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Compile  Link-edit LBTUTOR                          *
//* *                                                      *
//* -------------------------------------------------------*
//LBTUTOR  EXEC COBL,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=LBTUTOR,
//         CPARM1='LIST,LOAD,NODECK,PMAP,DMAP,LIB' 
//COB.STEPLIB  DD DSN=SYS1.LINKLIB,DISP=SHR          <--Complr STEPLIB
//COB.SYSLIB   DD DISP=SHR,DSN=&HLQ..&VRM..MACLIB    <-- Copybooks LIB
//LKED.SYSLMOD DD DSN=XXXXXXXX.ISPLLIB(&MBR),        <-- TARGET
//          DISP=SHR
//LKED.SYSLIB  DD DSN=SYS1.COBLIB,DISP=SHR           <--Complr COBLIB
//             DD DSN=ISP.V2R2M0.LLIB,DISP=SHR       <-- ISP SYS LLIB
//             DD DSN=XXXXXXXX.ISPLLIB,              <-- DYNBLOAD sub
//          DISP=SHR                                 <-- DYNBLOAD sub
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit LBPDSIOM                         *
//* *                                                      *
//* -------------------------------------------------------*
//LBPDSIOM EXEC  ASML,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=LBPDSIOM,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//         PARM.LKED='MAP,LIST,LET,XREF,NCAL'  
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
// 
______________________________________________________________________
Figure 5: $UP0900.JCL  Upgrade from previous version to V0R9M01

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading directly from V0R9M00, use $UP0901.JCL
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST03)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR3 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.LBTUTOR.V0R9M01.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.LBTUTOR.V0R9M01.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install LBTUTOR Software                                   |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST04)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR4 JOB (SYS),'Install LBTUTOR',      <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST04  Install LBTUTOR Software              *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: COBLKED                                       *
//* *       COBOL     Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//COBL     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT,
//             CPARM1='LOAD,SUPMAP',                                
//             CPARM2='SIZE=2048K,BUF=1024K'                        
//*COB EXEC  PGM=IKFCBL00,REGION=4096K,                             
//*          PARM='LOAD,SUPMAP,SIZE=2048K,BUF=1024K'                
//COB      EXEC PGM=IKFCBL00,REGION=4096K,                             
//           PARM='&CPARM1,&CPARM2'                                 
//STEPLIB  DD  DUMMY
//SYSPRINT DD  SYSOUT=*                                             
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT2   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT3   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT4   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(MOD,PASS),UNIT=SYSDA,             
//             SPACE=(80,(500,100))                                 
//SYSLIB   DD  DSN=&HLQ..&VRM..ASM,DISP=SHR
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='LIST,XREF,LET',
//             COND=(5,LT,COB),REGION=96K
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(OLD,DELETE)                      
//         DD  DDNAME=SYSIN                                                
//SYSLMOD  DD  DUMMY                                        
//SYSLIB   DD  DUMMY                  
//SYSUT1   DD  UNIT=SYSDA,SPACE=(1024,(50,20))                         
//SYSPRINT DD  SYSOUT=*                                              
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit DYNBLOAD to ISPLLIB              *
//* *                                                      *
//* -------------------------------------------------------*
//DYNBLOAD EXEC  ASML,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=DYNBLOAD,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//         PARM.LKED='MAP,LIST,LET,XREF'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit LBSTRC to ISPLLIB                *
//* *                                                      *
//* -------------------------------------------------------*
//LBSTRC   EXEC  ASML,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=LBSTRC,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//         PARM.LKED='MAP,LIST,LET,XREF,RENT,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit ZSELSCAN to ISPLLIB              *
//* *                                                      *
//* -------------------------------------------------------*
//ZSELSCAN EXEC  ASML,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=ZSELSCAN,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//         PARM.LKED='MAP,LIST,LET,XREF,RENT,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Compile  Link-edit LBTUTOR to ISPLLIB               *
//* *                                                      *
//* -------------------------------------------------------*
//LBTUTOR  EXEC COBL,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=LBTUTOR,
//         CPARM1='LIST,LOAD,NODECK,PMAP,DMAP,LIB' 
//COB.STEPLIB  DD DSN=SYS1.LINKLIB,DISP=SHR          <--Complr STEPLIB
//COB.SYSLIB   DD DISP=SHR,DSN=&HLQ..&VRM..MACLIB    <-- Copybooks LIB
//LKED.SYSLMOD DD DSN=XXXXXXXX.ISPLLIB(&MBR),        <-- TARGET
//          DISP=SHR
//LKED.SYSLIB  DD DSN=SYS1.COBLIB,DISP=SHR           <--Complr COBLIB
//             DD DSN=ISP.V2R2M0.LLIB,DISP=SHR       <-- ISP SYS LLIB
//             DD DSN=XXXXXXXX.ISPLLIB,              <-- DYNBLOAD sub
//          DISP=SHR                                 <-- DYNBLOAD sub
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit LBPDSIOM to ISPLLIB              *
//* *                                                      *
//* -------------------------------------------------------*
//LBPDSIOM EXEC  ASML,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,MBR=LBPDSIOM,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//         PARM.LKED='MAP,LIST,LET,XREF,NCAL'  
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
//                                      
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST05)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTOR5 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.LBTUTOR',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=C$LB2TR
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=LB2TR0
   SELECT MEMBER=LB2TR1
   SELECT MEMBER=LB2TR2
   SELECT MEMBER=LB2TR7
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PTUTR00
   SELECT MEMBER=HLB2TR0 
   SELECT MEMBER=TLB2TR00
   SELECT MEMBER=TLB2TR01
   SELECT MEMBER=TLB2TR02
   SELECT MEMBER=HTUTRIX
   SELECT MEMBER=HTUTR00
   SELECT MEMBER=HTUTR01
   SELECT MEMBER=HTUTR02
   SELECT MEMBER=HTUTR02B
   SELECT MEMBER=HTUTR03
   SELECT MEMBER=HTUTR04
   SELECT MEMBER=HTUTR05
   SELECT MEMBER=HTUTR06
   SELECT MEMBER=HTUTR07
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.LBTUTOR,V0R9M01.CNTL($INST40)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//LBTUTR40 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  LBTUTOR for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate LBTUTOR                                          |
+--------------------------------------------------------------------+


    a) From the ISPF Main Menu, enter the following command:

       TSO %C$LB2TR

    b) The panel titled 'Tutor Demo System' (PTUTR00) is displayed.

________________________________________________________________________________
 --Tutorial---------         Tutor Demo System           -----------------------
 Command ===>                                                                  
                                                                               
                           Application Main Menu
   This sample panel is a selection panel that serves as the main menu for an
   an application.

   The below numeric options are not operational and are for illustrative
   purposes.

   Select option T to start Tutorial Demo


        1 -  Option 1
        2 -  Option 2
        3 -  Option 3
        4 -  Option 4
        5 -  Option 5
        T -  Application Tutorial

       LT -  LBTUTOR Tutorial



________________________________________________________________________________
Figure 7: PTUTR00 Tutor Demo System panel


    c) Enter  T for sample tutorial.
       - or -
       Enter LT for LBTUTOR tutorial.

    d) Press ENTER.

    e) Validation is complete.



+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!  You completed the installation for LBTUTOR.


+--------------------------------------------------------------------+
| Step 13. Integrate LBTUTOR into an ISPF Selection Menu             |
+--------------------------------------------------------------------+


    a) To integrate LBTUTOR into a selection panel (menu) of your choice,
       follow the below steps -

    b) For example, use selection code T1 to display a tutorial about
       applicationxx whose first panel is PANEL1:

       Add a selection line to the panel )BODY section similar to
       the below snippet to display the LBTUTOR option:

        T1 +TUTORIAL 1  - Display information about applicationxx

    c) Add a entry to a TRANSlate function similar to the below
       snippet:

   'NEW ENTRY' line can be added to invoke new selection when new
   option code is typed followed by the ENTER key

     )PROC
       &ZSEL = TRANS( TRUNC (&ZCMD,'.')
                     1,'CMD(xxxxx) NEWAPPL(ISR)'
                     6,'PGM(xxxxxx)'
                     .
                     .
                    T1,'PGM(LBTUTOR)  PARM(PANEL1)'     <-- NEW ENTRY
                     .
                     .
                   ' ',' '
                     *,'?' )
     )END

    d) After applying update, redisplay the modified selection menu.
       The new menu option should display.

    e) Select the new option and press ENTER.

    f) The applicationxx tutorial should display.

    g) PF3 (END) to end tutorial.


Enjoy LBTUTOR!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.LBTUTOR,V0R9M01.ASM
 $ . LBTUTOR     Tutorial CP
   . DYNBLOAD    Subroutine - dynamic call for MVT COBOL
   . ZSELSCAN    Subroutine - scan help panel for ZSEL
   . LBSTRC      Subroutine - concatenate and display strings
 # . LBPDSIOM    Subroutine - Version of NCZ93205 to read pds members
                              from COBOL pgm

  - SHRABIT.LBTUTOR,V0R9M01.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.LBTUTOR,V0R9M01.CNTL
 $ . $INST00     Define Alias for HLQ LBTUTOR
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install LBTUTOR Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 $ . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 $ . $UP0901     Upgrade to V0R9M01   from   V0R9M00
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.LBTUTOR,V0R9M01.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.LBTUTOR,V0R9M01.ISPF
   . C$LB2TR     CLIST sample app to select tutorial from TSO

   . LB2TR0      LBTUTOR Messages
   . LB2TR1      LBTUTOR Messages
   . LB2TR2      LBTUTOR Messages
   . LB2TR7      LBTUTOR Messages

   . PTUTR00     LBTUTOR Dummy Main Menu panel
   . HLB2TR0     LBTUTOR Help panel

   . TLB2TR00    LBTUTOR Tutorial panel 1
   . TLB2TR01    LBTUTOR Tutorial panel 2
   . TLB2TR02    LBTUTOR Tutorial panel 3

   . Sample Tutorial Panels
   . HTUTRIX     Tutorial Index
   . HTUTR00     Tutorial table of contents (Parent panel, main menu)
   . HTUTR01     Tutorial option 1 panel
   . HTUTR02     Tutorial option 2 panel
   . HTUTR02B    Tutorial option 2 continuation panel (page 2)
   . HTUTR03     Tutorial option 3 panel
   . HTUTR04     Tutorial option 3.1 panel
   . HTUTR05     Tutorial option 3.2 panel
   . HTUTR06     Tutorial option 4 panel
   . HTUTR07     Tutorial option 5 panel

  - SHRABIT.LBTUTOR,V0R9M01.MACLIB
   . DVCTBL      Device Table Entries
   . ISPFPL      ISPF Parameter Address List (10)
   . ISPFSRV     ISPF Service keywords
   . ISPFSRVC    ISPF Service keywords (COBOL)
   . LA#ST       Load Address and Store
   . LBISPL      Call to ISPLINK (LarryB version)
   . MISCDC      Miscellaneous Constants (i.e. QUOTES)
   . MOVEC       Move VAR at R6, len reflected in R8 (requires MOVEI)
   . MOVEI       Init R6 w/ addr of VAR, init R8 to 0
   . MOVER       Move VAR at R6 until BLANK is found
   . MOVEV       Move VAR at R6
   . RDTECOMA    DateTime comm area
   . RDTECOMC    DateTime comm area (COBOL)
   . RTRIM       Remove trailing spaces
   . SVC78A      SVC78 message area


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




