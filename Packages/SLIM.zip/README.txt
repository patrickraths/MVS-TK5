# SLIM V1 R1 M0
Source LIbrary Manager - Programs to extend Archiver Files For MVS 3.8j

Welcome to SLIM.  This is a group of programs designed
to provide code management for users of Archiver.  The full use of
ARCHIVER is out of scope of this document.  Archiver 6.1.5 is
pre-installed on TK5 systems.  TK5 systems include a copy of the user
guide is the DOC folder.  It is also can be found at cbttape.org
File # 147 ARCHIVER All your non-VSAM datasets to 1 VSAM file .

SLIM, like Archiver, is designed for storage of almost any type of
non-VSAM file.  The file is stored in a VSAM KSDS (Keyed Sequential
Data Set) in a compressed and encrypted format.  One possible use of
Archiver is for secured storage of production source code. SLIM can also
store compiler generated listings and backup copies of the executable
load modules.

This repository of the SLIM is distributed as a 4 files.
After you unzip the file you downloaded, you should have the following
files.

    SLIM.XMI
    RESTTK5.txt  - restore to a TK5 system or systems with NJE38 installed.
    RESTOTHR.txt - restore to a system without NJE38 installed (uses RECV370)
                   systems other than TK5

BINARY upload the SLIM.XMI to the MVS system.  NOTE - in some cases you may
need to create an MVS dataset to upload into.  It should be fixed 80 byte
records.

Select the appropriate REST file for you system. If you use a HERCRDR program
(such as SPFLite2), you can submit the REST job from the PC.  Otherwise you
will need to TEXT upload the RESTxxxx to edit and submit it.

The RESTxxxx JCL defaults the catalog alias of SLIM. The volume to create
the datasets is a DASD you select. Within the JCL are comments on what to 
change.  You must make these change these before you submit or the job will fail.

Be sure to remove the TYPRUN before you submit the RESTxxxx.txt.

Option: Submit the job in the .CNTL(FINISH) to install the program and
procs into the system libraries.
