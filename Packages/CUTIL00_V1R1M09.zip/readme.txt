CUTIL00 for MVS3.8J / Hercules                                               
==============================                                               


Date: 04/15/2024  Release V1R1M09
      02/14/2024  Release V1R1M08  * not released
      06/07/2023  Release V1R1M07  * not released
      01/31/2023  Release V1R1M06
      10/05/2021  Release V1R1M05
       4/10/2021  Release V1R1M00
       5/03/2020  Release V1R0M10
       3/20/2020  Release V1R0M00  **INITIAL software distribution

*  Author: Larry Belmontes Jr.
*          https://ShareABitOfIT.net/CUTIL00-for-mvs-3-8j/
*          Copyright (C) 2020-2024 Larry Belmontes, Jr.


----------------------------------------------------------------------
|    CUTIL00      I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Good luck and enjoy this software as added value to MVS 3.8J!
-Larry Belmontes



----------------------------------------------------------------------
|    CUTIL00      C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*
*  MM/DD/CCYY Version  Change Description
*  ---------- -------  -----------------------------------------------
*  04/15/2024 1.1.09   - Correct REPLACE function to return # of changed
*                        sub-strings in RC
*                      - Correct ZFILL to return zeros when blank string
*                        is passed
*                      - Add new panel to display results from MCAL  
*                        and MCALA
*
*  02/14/2024 1.1.08   - Add MYTUTOR command to panel from CCUTIL0I
*                      - Add tutorial screens
*                      - Correct '2J2M' function in CUTILTBL module
*                      - Stop command line parse when '/*' (comment)
*                        is detected in CUTIL00 module
*                      - Miscellaneous documentation and program updates
*
*  06/07/2023 1.1.07   - Add trailing attribute4 at end of month
*                        for MCALA function and documentation update
*
*  01/31/2023 1.1.06   - Add new functions ISHEX H2C C2H ISEVEN
*                      - Modify MCALA function to use hex attributes
*                      - Miscellaneous documentation and program updates
*
*  10/05/2021 1.1.05   - Add new functions LEN SLEN OVERLAY UTDSN TRUNC
*                      - Correction to REPLACE function
*                      - Load CUTILTBL and call via BALR
*                      - Miscellaneous documentation and program updates
*
*  04/10/2021 1.1.00   - Add new functions GET1 PUT1 MCAL
*                      - Externalize constants and tables to new program
*                      - Miscellaneous documentation and program updates
*
*  05/03/2020 1.0.10   - Change software distribution packaging and
*                        installation procedure to use Hercules 
*                        Emulated Tape (HET)
*                      - No change to CUTIL00 program
*
*  04/20/2020 1.0.01   - Correction to Step ADDHELP in $inst01.JCL to
*                        load two HELP members instead of one
*                      - Thanks to Tom Armstrong!!
*
*  03/20/2020 1.0.00   Initial version released to MVS 3.8J
*                      hobbyist public domain
*
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  CUTIL00.V1R1M09.HET  Hercules Emulated Tape (HET) multi-file volume
   volser=VS1109        containing software distribution library.

o  CUTIL00.V1R1M09.XMI  XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.0+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/



======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.CUTIL00.V1R1M09.ASM                  PUB006    50    17 PO  FB  34  1
   SHRABIT.CUTIL00.V1R1M09.CLIST                PUB006    15     4 PO  FB  26  1
   SHRABIT.CUTIL00.V1R1M09.CNTL                 PUB006    20     7 PO  FB  35  1
   SHRABIT.CUTIL00.V1R1M09.HELP                 PUB006     4     1 PO  FB  25  1
   SHRABIT.CUTIL00.V1R1M09.ISPF                 PUB006    40    34 PO  FB  85  1
   SHRABIT.CUTIL00.V1R1M09.MACLIB               PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:     131 TRKS ALLOC        64 TRKS USED       6 EXTENTS    


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($RECVXMI)         |
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($RECVTSO)         |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive CUTIL00 XMI',      <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 DVTOC Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(40,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(50,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for CUTIL00 software distribution    *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE CUTIL00 Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.CUTIL00.V1R1M09.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(CNTL)') -  
        DA('SHRABIT.CUTIL00.V1R1M09.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(HELP)') -  
        DA('SHRABIT.CUTIL00.V1R1M09.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(CLIST)') -  
        DA('SHRABIT.CUTIL00.V1R1M09.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(ISPF)') -  
        DA('SHRABIT.CUTIL00.V1R1M09.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(ASM)') -  
        DA('SHRABIT.CUTIL00.V1R1M09.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.CUTIL00.V1R1M09.XMIPDS(MACLIB)') - 
        DA('SHRABIT.CUTIL00.V1R1M09.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.CUTIL00.V1R1M09.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVXMI.JCL


    a) Transfer CUTIL00.V1R1M09.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.CUTIL00.V1R1M09.ASM
       SHRABIT.CUTIL00.V1R1M09.CLIST
       SHRABIT.CUTIL00.V1R1M09.CNTL
       SHRABIT.CUTIL00.V1R1M09.HELP
       SHRABIT.CUTIL00.V1R1M09.ISPF
       SHRABIT.CUTIL00.V1R1M09.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ SHRABIT in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST00)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL000 JOB (SYS),'Def CUTIL00 Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 1: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST01)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL001 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=CUTIL00,TVOLSER=VS1109,
//   HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CUTIL00.V1R1M09.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST02)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL002 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=CUTIL00,TVOLSER=VS1109,
//   HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(40,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(50,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CUTIL00.V1R1M09.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($UP1109)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL00U JOB (SYS),'Upgrade CUTIL00',      <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $UP1109                                        *
//* *       Upgrade CUTIL00 Software from release V1R1M06  *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.CUTIL00.V1R1M09.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.CUTIL00.V1R1M09.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=CCUTIL00
/*                                                                  
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit CUTIL00  to SYS2.CMDLIB          *
//* -------------------------------------------------------*
//CUTILTBL EXEC  ASML,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,MBR=CUTIL00, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit CUTILTBL to SYS2.CMDLIB          *
//* -------------------------------------------------------*
//CUTILTBL EXEC  ASML,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,MBR=CUTILTBL, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *  ISPF Components                                     *
//* -------------------------------------------------------*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CCUTIL0I
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PCUTIL00
   SELECT MEMBER=PCUTIL01
   SELECT MEMBER=HCUTIL00
   SELECT MEMBER=TCUTF01A
   SELECT MEMBER=TCUTF01B
   SELECT MEMBER=TCUTF02A
   SELECT MEMBER=TCUTF02B
   SELECT MEMBER=TCUTF03A
   SELECT MEMBER=TCUTF03B
   SELECT MEMBER=TCUTF04A
   SELECT MEMBER=TCUTF04B
   SELECT MEMBER=TCUTF07A
   SELECT MEMBER=TCUTF07B
   SELECT MEMBER=TCUTF08A
   SELECT MEMBER=TCUTF08B
   SELECT MEMBER=TCUTF09A
   SELECT MEMBER=TCUTF09B
   SELECT MEMBER=TCUTF10A
   SELECT MEMBER=TCUTF10B
   SELECT MEMBER=TCUTF11A
   SELECT MEMBER=TCUTF11B
   SELECT MEMBER=TCUTF12A
   SELECT MEMBER=TCUTF12B
   SELECT MEMBER=TCUTF13A
   SELECT MEMBER=TCUTF13B
   SELECT MEMBER=TCUTF14A
   SELECT MEMBER=TCUTF14B
   SELECT MEMBER=TCUTF15A
   SELECT MEMBER=TCUTF15B
   SELECT MEMBER=TCUTF16A
   SELECT MEMBER=TCUTF16B
   SELECT MEMBER=TCUTF17A
   SELECT MEMBER=TCUTF17B
   SELECT MEMBER=TCUTF18A
   SELECT MEMBER=TCUTF18B
   SELECT MEMBER=TCUTF19A
   SELECT MEMBER=TCUTF19B
   SELECT MEMBER=TCUTF20A
   SELECT MEMBER=TCUTF20B
   SELECT MEMBER=TCUTF21A
   SELECT MEMBER=TCUTF21B
   SELECT MEMBER=TCUTF22A
   SELECT MEMBER=TCUTF22B
   SELECT MEMBER=TCUTF23A
   SELECT MEMBER=TCUTF23B
   SELECT MEMBER=TCUTF24A
   SELECT MEMBER=TCUTF24B
   SELECT MEMBER=TCUTF25A
   SELECT MEMBER=TCUTF25B
   SELECT MEMBER=TCUTF26A
   SELECT MEMBER=TCUTF26B
   SELECT MEMBER=TCUTF27A
   SELECT MEMBER=TCUTF27B
   SELECT MEMBER=TCUTF28A
   SELECT MEMBER=TCUTF28B
   SELECT MEMBER=TCUTF29A
   SELECT MEMBER=TCUTF29B
   SELECT MEMBER=TCUTF30A
   SELECT MEMBER=TCUTF30B
   SELECT MEMBER=TCUTF31A
   SELECT MEMBER=TCUTF31B
   SELECT MEMBER=TCUTF32A
   SELECT MEMBER=TCUTF32B
   SELECT MEMBER=TCUTF33A
   SELECT MEMBER=TCUTF33B
   SELECT MEMBER=TCUTF34A
   SELECT MEMBER=TCUTF34B
   SELECT MEMBER=TCUTF35A
   SELECT MEMBER=TCUTF35B
   SELECT MEMBER=TCUTF36A
   SELECT MEMBER=TCUTF36B
   SELECT MEMBER=TCUTF37A
   SELECT MEMBER=TCUTF37B
   SELECT MEMBER=TCUTF38A
   SELECT MEMBER=TCUTF38B
   SELECT MEMBER=TCUTF39A
   SELECT MEMBER=TCUTF39B
   SELECT MEMBER=TCUTF40A
   SELECT MEMBER=TCUTF40B
   SELECT MEMBER=TCUTF41A
   SELECT MEMBER=TCUTF41B
   SELECT MEMBER=TCUTF42A
   SELECT MEMBER=TCUTF42B
   SELECT MEMBER=TCUTF43A
   SELECT MEMBER=TCUTF43B
   SELECT MEMBER=TCUTF44A
   SELECT MEMBER=TCUTF44B
   SELECT MEMBER=TCUTF45A
   SELECT MEMBER=TCUTF45B
   SELECT MEMBER=TCUTF46A
   SELECT MEMBER=TCUTF46B
   SELECT MEMBER=TCUTF47A
   SELECT MEMBER=TCUTF47B
   SELECT MEMBER=TCUTF48A
   SELECT MEMBER=TCUTF48B
   SELECT MEMBER=TCUTF49A
   SELECT MEMBER=TCUTF49B
   SELECT MEMBER=TCUTF50A
   SELECT MEMBER=TCUTF50B
   SELECT MEMBER=TCUTF51A
   SELECT MEMBER=TCUTF51B
   SELECT MEMBER=TCUTF52A
   SELECT MEMBER=TCUTF52B
   SELECT MEMBER=TCUTF53A
   SELECT MEMBER=TCUTF53B
   SELECT MEMBER=TCUTF54A
   SELECT MEMBER=TCUTF54B
   SELECT MEMBER=TCUTF55A
   SELECT MEMBER=TCUTF55B
   SELECT MEMBER=TCUTF56A
   SELECT MEMBER=TCUTF56B
   SELECT MEMBER=TCUTF57A
   SELECT MEMBER=TCUTF57B
   SELECT MEMBER=TCUTF58A
   SELECT MEMBER=TCUTF58B
   SELECT MEMBER=TCUTF59A
   SELECT MEMBER=TCUTF59B
   SELECT MEMBER=TCUTF60A
   SELECT MEMBER=TCUTF60B
   SELECT MEMBER=TCUTF61A
   SELECT MEMBER=TCUTF61B
   SELECT MEMBER=TCUTF62A
   SELECT MEMBER=TCUTF62B
   SELECT MEMBER=TCUTF62C
   SELECT MEMBER=TCUTF63A
   SELECT MEMBER=TCUTF63B
   SELECT MEMBER=TCUTF64A
   SELECT MEMBER=TCUTF64B
   SELECT MEMBER=TCUTF65A
   SELECT MEMBER=TCUTF65B
   SELECT MEMBER=TCUTF66A
   SELECT MEMBER=TCUTF66B
   SELECT MEMBER=TCUTF67A
   SELECT MEMBER=TCUTF67B
   SELECT MEMBER=TCUTF68A
   SELECT MEMBER=TCUTF68B
   SELECT MEMBER=TCUTF69A
   SELECT MEMBER=TCUTF69B
   SELECT MEMBER=TCUTF70A
   SELECT MEMBER=TCUTF70B
   SELECT MEMBER=TCUTF70C
   SELECT MEMBER=TCUTF71A
   SELECT MEMBER=TCUTF71B
   SELECT MEMBER=TCUTF71C
   SELECT MEMBER=TCUTF72A
   SELECT MEMBER=TCUTF72B
   SELECT MEMBER=TCUTF73A
   SELECT MEMBER=TCUTF73B
   SELECT MEMBER=TCUTF74A
   SELECT MEMBER=TCUTF74B
   SELECT MEMBER=TCUTF75A
   SELECT MEMBER=TCUTF75B
   SELECT MEMBER=TCUTF76A
   SELECT MEMBER=TCUTF76B
   SELECT MEMBER=TCUTF77A
   SELECT MEMBER=TCUTF77B
   SELECT MEMBER=TCUTF78A
   SELECT MEMBER=TCUTF78B
   SELECT MEMBER=TCUTF79A
   SELECT MEMBER=TCUTF79B
   SELECT MEMBER=TCUTF80A
   SELECT MEMBER=TCUTF80B
   SELECT MEMBER=TCUTL001
   SELECT MEMBER=TCUTL002
   SELECT MEMBER=TCUTL003
   SELECT MEMBER=TCUTL100
   SELECT MEMBER=TCUTLA01
   SELECT MEMBER=TCUTLA02
   SELECT MEMBER=TCUTLA03
   SELECT MEMBER=TCUTLB01
   SELECT MEMBER=TCUTLB02
   SELECT MEMBER=TCUTLB03
   SELECT MEMBER=TCUTLB04
   SELECT MEMBER=TCUTLC01
   SELECT MEMBER=TCUTLC02
   SELECT MEMBER=TCUTLC03
   SELECT MEMBER=TCUTLC04
   SELECT MEMBER=TCUTLC05
   SELECT MEMBER=TCUTLC06
   SELECT MEMBER=TCUTLC07
   SELECT MEMBER=TCUTLD01
   SELECT MEMBER=TCUTLD02
   SELECT MEMBER=TCUTLD03
   SELECT MEMBER=TCUTLD04
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//*
//* -------------------------------------------------------*
//* *  If SYSn.LINKLIB or SYSn.CMDLIB is updated           *
//* -------------------------------------------------------*
//DBSTOP   EXEC DBSTOP,
//             COND=(0,NE)               
//DBSTART  EXEC DBSTART,
//             COND=(0,NE)                
// 
______________________________________________________________________
Figure 5: $UP1109.JCL  Upgrade from previous version to V1R1M09

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading from V1R1M06, use $UP1109.JCL
       - All other releases must be full installs!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST03)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL003 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.CUTIL00.V1R1M09.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.CUTIL00.V1R1M09.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=CCUTIL00
    SELECT MEMBER=CCUTIL0V
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=CUTIL00
    SELECT MEMBER=CCUTIL00
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install CUTIL00 Software                                   |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST04)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL004 JOB (SYS),'Install CUTIL00',      <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST04  Install CUTIL00 Software              *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit CUTIL00 to SYS2.CMDLIB           *
//* -------------------------------------------------------*
//CUTIL00  EXEC  ASML,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,MBR=CUTIL00,
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit CUTILTBL to SYS2.CMDLIB          *
//* -------------------------------------------------------*
//CUTILTBL EXEC  ASML,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,MBR=CUTILTBL, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  If SYSn.LINKLIB or SYSn.CMDLIB is updated           *
//* *                                                      *
//* -------------------------------------------------------*
//DBSTOP   EXEC DBSTOP,
//             COND=(0,NE)               
//DBSTART  EXEC DBSTART,
//             COND=(0,NE)                
// 
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST05)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL005 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.CUTIL00',VRM=V1R1M09,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CCUTIL0I
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=CUTIL0 
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PCUTIL00
   SELECT MEMBER=PCUTIL01
   SELECT MEMBER=HCUTIL00
   SELECT MEMBER=TCUTF01A
   SELECT MEMBER=TCUTF01B
   SELECT MEMBER=TCUTF02A
   SELECT MEMBER=TCUTF02B
   SELECT MEMBER=TCUTF03A
   SELECT MEMBER=TCUTF03B
   SELECT MEMBER=TCUTF04A
   SELECT MEMBER=TCUTF04B
   SELECT MEMBER=TCUTF07A
   SELECT MEMBER=TCUTF07B
   SELECT MEMBER=TCUTF08A
   SELECT MEMBER=TCUTF08B
   SELECT MEMBER=TCUTF09A
   SELECT MEMBER=TCUTF09B
   SELECT MEMBER=TCUTF10A
   SELECT MEMBER=TCUTF10B
   SELECT MEMBER=TCUTF11A
   SELECT MEMBER=TCUTF11B
   SELECT MEMBER=TCUTF12A
   SELECT MEMBER=TCUTF12B
   SELECT MEMBER=TCUTF13A
   SELECT MEMBER=TCUTF13B
   SELECT MEMBER=TCUTF14A
   SELECT MEMBER=TCUTF14B
   SELECT MEMBER=TCUTF15A
   SELECT MEMBER=TCUTF15B
   SELECT MEMBER=TCUTF16A
   SELECT MEMBER=TCUTF16B
   SELECT MEMBER=TCUTF17A
   SELECT MEMBER=TCUTF17B
   SELECT MEMBER=TCUTF18A
   SELECT MEMBER=TCUTF18B
   SELECT MEMBER=TCUTF19A
   SELECT MEMBER=TCUTF19B
   SELECT MEMBER=TCUTF20A
   SELECT MEMBER=TCUTF20B
   SELECT MEMBER=TCUTF21A
   SELECT MEMBER=TCUTF21B
   SELECT MEMBER=TCUTF22A
   SELECT MEMBER=TCUTF22B
   SELECT MEMBER=TCUTF23A
   SELECT MEMBER=TCUTF23B
   SELECT MEMBER=TCUTF24A
   SELECT MEMBER=TCUTF24B
   SELECT MEMBER=TCUTF25A
   SELECT MEMBER=TCUTF25B
   SELECT MEMBER=TCUTF26A
   SELECT MEMBER=TCUTF26B
   SELECT MEMBER=TCUTF27A
   SELECT MEMBER=TCUTF27B
   SELECT MEMBER=TCUTF28A
   SELECT MEMBER=TCUTF28B
   SELECT MEMBER=TCUTF29A
   SELECT MEMBER=TCUTF29B
   SELECT MEMBER=TCUTF30A
   SELECT MEMBER=TCUTF30B
   SELECT MEMBER=TCUTF31A
   SELECT MEMBER=TCUTF31B
   SELECT MEMBER=TCUTF32A
   SELECT MEMBER=TCUTF32B
   SELECT MEMBER=TCUTF33A
   SELECT MEMBER=TCUTF33B
   SELECT MEMBER=TCUTF34A
   SELECT MEMBER=TCUTF34B
   SELECT MEMBER=TCUTF35A
   SELECT MEMBER=TCUTF35B
   SELECT MEMBER=TCUTF36A
   SELECT MEMBER=TCUTF36B
   SELECT MEMBER=TCUTF37A
   SELECT MEMBER=TCUTF37B
   SELECT MEMBER=TCUTF38A
   SELECT MEMBER=TCUTF38B
   SELECT MEMBER=TCUTF39A
   SELECT MEMBER=TCUTF39B
   SELECT MEMBER=TCUTF40A
   SELECT MEMBER=TCUTF40B
   SELECT MEMBER=TCUTF41A
   SELECT MEMBER=TCUTF41B
   SELECT MEMBER=TCUTF42A
   SELECT MEMBER=TCUTF42B
   SELECT MEMBER=TCUTF43A
   SELECT MEMBER=TCUTF43B
   SELECT MEMBER=TCUTF44A
   SELECT MEMBER=TCUTF44B
   SELECT MEMBER=TCUTF45A
   SELECT MEMBER=TCUTF45B
   SELECT MEMBER=TCUTF46A
   SELECT MEMBER=TCUTF46B
   SELECT MEMBER=TCUTF47A
   SELECT MEMBER=TCUTF47B
   SELECT MEMBER=TCUTF48A
   SELECT MEMBER=TCUTF48B
   SELECT MEMBER=TCUTF49A
   SELECT MEMBER=TCUTF49B
   SELECT MEMBER=TCUTF50A
   SELECT MEMBER=TCUTF50B
   SELECT MEMBER=TCUTF51A
   SELECT MEMBER=TCUTF51B
   SELECT MEMBER=TCUTF52A
   SELECT MEMBER=TCUTF52B
   SELECT MEMBER=TCUTF53A
   SELECT MEMBER=TCUTF53B
   SELECT MEMBER=TCUTF54A
   SELECT MEMBER=TCUTF54B
   SELECT MEMBER=TCUTF55A
   SELECT MEMBER=TCUTF55B
   SELECT MEMBER=TCUTF56A
   SELECT MEMBER=TCUTF56B
   SELECT MEMBER=TCUTF57A
   SELECT MEMBER=TCUTF57B
   SELECT MEMBER=TCUTF58A
   SELECT MEMBER=TCUTF58B
   SELECT MEMBER=TCUTF59A
   SELECT MEMBER=TCUTF59B
   SELECT MEMBER=TCUTF60A
   SELECT MEMBER=TCUTF60B
   SELECT MEMBER=TCUTF61A
   SELECT MEMBER=TCUTF61B
   SELECT MEMBER=TCUTF62A
   SELECT MEMBER=TCUTF62B
   SELECT MEMBER=TCUTF62C
   SELECT MEMBER=TCUTF63A
   SELECT MEMBER=TCUTF63B
   SELECT MEMBER=TCUTF64A
   SELECT MEMBER=TCUTF64B
   SELECT MEMBER=TCUTF65A
   SELECT MEMBER=TCUTF65B
   SELECT MEMBER=TCUTF66A
   SELECT MEMBER=TCUTF66B
   SELECT MEMBER=TCUTF67A
   SELECT MEMBER=TCUTF67B
   SELECT MEMBER=TCUTF68A
   SELECT MEMBER=TCUTF68B
   SELECT MEMBER=TCUTF69A
   SELECT MEMBER=TCUTF69B
   SELECT MEMBER=TCUTF70A
   SELECT MEMBER=TCUTF70B
   SELECT MEMBER=TCUTF70C
   SELECT MEMBER=TCUTF71A
   SELECT MEMBER=TCUTF71B
   SELECT MEMBER=TCUTF71C
   SELECT MEMBER=TCUTF72A
   SELECT MEMBER=TCUTF72B
   SELECT MEMBER=TCUTF73A
   SELECT MEMBER=TCUTF73B
   SELECT MEMBER=TCUTF74A
   SELECT MEMBER=TCUTF74B
   SELECT MEMBER=TCUTF75A
   SELECT MEMBER=TCUTF75B
   SELECT MEMBER=TCUTF76A
   SELECT MEMBER=TCUTF76B
   SELECT MEMBER=TCUTF77A
   SELECT MEMBER=TCUTF77B
   SELECT MEMBER=TCUTF78A
   SELECT MEMBER=TCUTF78B
   SELECT MEMBER=TCUTF79A
   SELECT MEMBER=TCUTF79B
   SELECT MEMBER=TCUTF80A
   SELECT MEMBER=TCUTF80B
   SELECT MEMBER=TCUTL001
   SELECT MEMBER=TCUTL002
   SELECT MEMBER=TCUTL003
   SELECT MEMBER=TCUTL100
   SELECT MEMBER=TCUTLA01
   SELECT MEMBER=TCUTLA02
   SELECT MEMBER=TCUTLA03
   SELECT MEMBER=TCUTLB01
   SELECT MEMBER=TCUTLB02
   SELECT MEMBER=TCUTLB03
   SELECT MEMBER=TCUTLB04
   SELECT MEMBER=TCUTLC01
   SELECT MEMBER=TCUTLC02
   SELECT MEMBER=TCUTLC03
   SELECT MEMBER=TCUTLC04
   SELECT MEMBER=TCUTLC05
   SELECT MEMBER=TCUTLC06
   SELECT MEMBER=TCUTLC07
   SELECT MEMBER=TCUTLD01
   SELECT MEMBER=TCUTLD02
   SELECT MEMBER=TCUTLD03
   SELECT MEMBER=TCUTLD04
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($INST40)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//CUTIL040 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate CUTIL00                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($IVP1)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//IVP1     JOB (SYS),'CUTIL00 IPV1',         <-- Review and Modify           
//         CLASS=A,MSGCLASS=A,               <-- Review and Modify 
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify 
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $IVP1                                          *
//* *       Run CUTIL00 Validation                         *
//* *                                                      *
//* *  CUTIL00 validation via CCLIST0V using BATCH TSO     *
//* *  of documented function in program documentation.    *
//* *                                                      *
//* *  Note: CLIST are resolved from SYS2.CMDPROC          *
//* *        and tagged with <--TARGET for search          *
//* *        purposes.                                     *
//* -------------------------------------------------------*
//BATCHTSO PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           <--TARGET
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//         PEND
//*
//TESTIT0  EXEC BATCHTSO 
//STEP01.SYSTSIN DD *
CCUTIL0V                                  
/*
//
______________________________________________________________________
Figure 10: $IVP1 JCL
 
 
    a) Member $IVP1 validates CUTIL00.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Submit the job.
 
    d) Review job output for successful execution.  Return codes will
       vary but a PASS / FAIL message is displayed for each function.
       Expected results are all PASS.                                 
 
 
+--------------------------------------------------------------------+
| Step 12. CUTIL00 Samples                                           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CUTIL00.V1R1M09.CNTL($SAMPLES)         |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//IVPS     JOB (SYS),'CUTIL00 IPVS',         <-- Review and Modify           
//         CLASS=A,MSGCLASS=A,               <-- Review and Modify 
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify 
//* -------------------------------------------------------*
//* *  CUTIL00 for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $IVP1                                          *
//* *       Run CUTIL00 Samples                            *
//* *                                                      *
//* *  CUTIL00 validation via CCUTIL00 using BATCH TSO     *
//* *  of sample functions.                                *
//* *                                                      *
//* *  Note: CLIST are resolved from SYS2.CMDPROC          *
//* *        and tagged with <--TARGET for search          *
//* *        purposes.                                     *
//* -------------------------------------------------------*
//BATCHTSO PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           <--TARGET
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//         PEND
//*
//TESTITS  EXEC BATCHTSO 
//STEP01.SYSTSIN DD *
CCUTIL00 ABOUT VERBOSE(N)
CCUTIL00 LTRIM    VAR01('   LEADING SPACES') VAR02('')  VERBOSE(N)
CCUTIL00 RTRIM    VAR01('TRAILING SPACES  ') VAR02('')  VERBOSE(N)
CCUTIL00 TRIM     VAR01(' TRIM   MY  DATA ') VAR02('')  VERBOSE(N)
CCUTIL00 TRIM$    VAR01(' TRIM   MY  DATA ') VAR02('')  VERBOSE(N)
CCUTIL00 INDEX    VAR01('MY, STRING, OK?   ') VAR02('","')  VERBOSE(N)
CCUTIL00 INDEXB   VAR01('MY, STRING, OK?   ') VAR02('","')  VERBOSE(N)
CCUTIL00 ISNUM    VAR01('0123456789') VERBOSE(N)
CCUTIL00 ISALPHA  VAR01('ABCDEFGHIJ') VERBOSE(N)
CCUTIL00 ISLOWER  VAR01('abcdefghij') VERBOSE(N)
CCUTIL00 ISUPPER  VAR01('ABCDEFGHIJ') VERBOSE(N)
CCUTIL00 ISBLANK  VAR01('         ') VERBOSE(N)
CCUTIL00 ISDSN    VAR01('A.A1234567') VERBOSE(N)
CCUTIL00 ECHO     VAR01('MY DATA TO DISPLAY') VERBOSE(N)
CCUTIL00 ECHOQ    VAR01('MY DATA TO DISPLAY') VERBOSE(N)
CCUTIL00 REVRS    VAR01('ABCDEFGHIJKLM96%QRS') VAR02('') VERBOSE(N)
CCUTIL00 UPPERC   VAR01('ABCDEFGHIJKLMNOPQRS') VERBOSE(N)
CCUTIL00 LOWERC   VAR01('ABCDEFGHIJKLMNOPQRS') VAR02('') VERBOSE(N)
CCUTIL00 COUNT    VAR01('MY NAME IS DINO, BIG DINO.') VAR02('"DINO"') -        
 VERBOSE(N)
CCUTIL00 FIND     VAR01('MY NAME IS DINO, BIG DINO.') VAR02('"DINO"') -        
 VERBOSE(N)
CCUTIL00 FINDL    VAR01('MY NAME IS DINO, BIG DINO.') VAR02('"DINO"') -        
 VERBOSE(N)
CCUTIL00 CENTER   VAR01('CENTER THIS T E X T ...       ') VAR02('') -
 VERBOSE(N)
CCUTIL00 LJUST    VAR01(' JUSTIFY THIS TEXT    ') VAR02('') VERBOSE(N)
CCUTIL00 RJUST    VAR01(' JUSTIFY THIS TEXT    ') VAR02('') VERBOSE(N)
CCUTIL00 ZFILL    VAR01('12   ') VAR02('') VERBOSE(N)
CCUTIL00 WORDS    VAR01('  ONE TEWO THREE33 FOUR., FIVE ') VERBOSE(N)
CCUTIL00 GEN#     VAR01('') VERBOSE(N)
CCUTIL00 DD2DSN   VAR01('SYSPROC') VAR02('') VERBOSE(N)
CCUTIL00 JOBINFO  VAR01('') VERBOSE(N)
CCUTIL00 DAYSMM   VAR01('022016') VERBOSE(N)
CCUTIL00 DAYSYY   VAR01('2020') VERBOSE(N)
CCUTIL00 ISLEAP   VAR01('2020') VERBOSE(N)
 
CCUTIL00 CYJ-D8   VAR01('2020061') VAR02('') VERBOSE(N)
CCUTIL00 CYJ-DAY  VAR01('1981061') VAR02('') VERBOSE(N)
CCUTIL00 CYJ-DOW  VAR01('1981061') VAR02('') VERBOSE(N)
CCUTIL00 CYJ-MDCY VAR01('2020061') VAR02('') VERBOSE(N)
 
CCUTIL00 JCY-D8   VAR01('1612017') VAR02('') VERBOSE(N)
CCUTIL00 JCY-DAY  VAR01('0611981') VAR02('') VERBOSE(N)
CCUTIL00 JCY-DOW  VAR01('0611981') VAR02('') VERBOSE(N)
CCUTIL00 JCY-MDCY VAR01('1612017') VAR02('') VERBOSE(N)
 
CCUTIL00 MDCY-D8  VAR01('12101990') VAR02('') VERBOSE(N)
CCUTIL00 MDCY-DAY VAR01('12101990') VAR02('') VERBOSE(N)
CCUTIL00 MDCY-DOW VAR01('12101990') VAR02('') VERBOSE(N)
CCUTIL00 MDCY-CYJ VAR01('12101990') VAR02('') VERBOSE(N)
 
CCUTIL00 DMCY-D8  VAR01('15071987') VAR02('') VERBOSE(N)
CCUTIL00 DMCY-DAY VAR01('15071987') VAR02('') VERBOSE(N)
CCUTIL00 DMCY-DOW VAR01('15071987') VAR02('') VERBOSE(N)
CCUTIL00 DMCY-CYJ VAR01('15071987') VAR02('') VERBOSE(N)
 
CCUTIL00 CYMD-D8  VAR01('19951231') VAR02('') VERBOSE(N)
CCUTIL00 CYMD-DAY VAR01('19951231') VAR02('') VERBOSE(N)
CCUTIL00 CYMD-DOW VAR01('19951231') VAR02('') VERBOSE(N)
CCUTIL00 CYMD-CYJ VAR01('19951231') VAR02('') VERBOSE(N)
 
CCUTIL00 CYDM-D8  VAR01('19951605') VAR02('') VERBOSE(N)
CCUTIL00 CYDM-DAY VAR01('19951605') VAR02('') VERBOSE(N)
CCUTIL00 CYDM-DOW VAR01('19951605') VAR02('') VERBOSE(N)
CCUTIL00 CYDM-CYJ VAR01('19951605') VAR02('') VERBOSE(N)
CCUTIL00 FILL     VAR01('') VAR02('*20') VERBOSE(N)
CCUTIL00 LSTRIP   VAR01(',,28,BC,') VAR02(',') VERBOSE(N)
CCUTIL00 RSTRIP   VAR01(',,28,BC,') VAR02(',') VERBOSE(N)
CCUTIL00 STRIP    VAR01(',,28,BC,') VAR02(',') VERBOSE(N)
CCUTIL00 STRIP$   VAR01(',,28,BC,') VAR02(',') VERBOSE(N)
CCUTIL00 CONCAT   VAR01('STRING DATA 1.') -     
 VAR02('A RESULT STRING 2.') VERBOSE(N)   
CCUTIL00 UNSTR    VAR01('1234567 AND SO ON . I AM 78 LONG. ') -     
 VAR02('7') VERBOSE(N)       
CCUTIL00 REPLACE  VAR01('1234567 AND SO ON . I AM 7879.') -     
 VAR02('"SO ON ","890123456--"') VERBOSE(N)       
CCUTIL00 VEXIST   VAR01('VAR01') VERBOSE(N)
CCUTIL00 VEXIST   VAR01('DDD01') VERBOSE(N)
CCUTIL00 TDSN     VAR01('HERC01.CARDS.') VERBOSE(N)
CCUTIL00 NOW      VAR01('') VERBOSE(N)
CCUTIL00 PAD      VAR01('MAKE ME 30 LONG') VAR02(' 30') VERBOSE (N)
CCUTIL00 GET1V    VAR01('THE TABLE TOP IS CLEAR') VAR02('x11') -
 VERBOSE (N)
CCUTIL00 PUT1V    VAR01('THE TABLE TOP IS CLEAR') VAR02('N22') -
 VERBOSE (N)
CCUTIL00 MCAL     VAR01('') VAR02('') VERBOSE (N)
CCUTIL00 LEN      VAR01(' MY WORD IN THE STRING    ')          -
 VERBOSE (N)
CCUTIL00 SLEN     VAR01(' MY WORD IN THE STRING    ')          -
 VERBOSE (N)
CCUTIL00 OVERLAY  VAR01(' MY TEXT TO BE OVERLAYED OK!! ')      -
 VAR02('"----- ",7') VERBOSE(N)       
CCUTIL00 UTDSN    VAR01('CARDS') VERBOSE (N)                     
CCUTIL00 TRUNC    VAR01('THE MAN WALKED HERE') -           
 VAR02('x07') VERBOSE(N)       
CCUTIL00 ISHEX    VAR01('A123FA67BD') VERBOSE(N)
CCUTIL00 CC2H     VAR01('1995STAR') VERBOSE(N)
CCUTIL00 CH2C     VAR01('C1C203') VERBOSE(N)
CCUTIL00 ISEVEN   VAR01('1234567890') VERBOSE(N)
/*
//
______________________________________________________________________
Figure 11: $SAMPLES JCL
 
 
    a) Member $SAMPLES runs the CUTIL00 program samples using PROC CCUTIL00.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Submit the job.
 
    d) Review job output at your leisure.  Return codes will vary by 
       function.                        
 
 
+--------------------------------------------------------------------+
| Step 13. Validate CUTIL00 ISPF 2.x application                     |
+--------------------------------------------------------------------+
 
 
    a) This step can be omitted if ISPF 2.x is NOT installed on
       your system.  Proceed to the next step.                       
 
    b) From the ISPF Main Menu, select option 6, COMMAND.  The TSO
       COMMAND PROCESSOR panel will display. 
 
    c) Enter the TSO command:
       %CCUTIL0I
 
    d) The panel PCUTIL00, CUTIL00 for MVS 38J, is displayed.
       Type the following information in the upper left corner:
       o  Type JOBINFO for FUNCTION
       o  Type N for VAR1 Quote
       o  Type N for VAR2 Use
       o  Press ENTER                                                         
       o  Results will display under VAR1 ruler on the panel       
          Comprised of three 8-byte fields -
              Userid, TSO proc name, and Logon proc name 
       o  Press PF1 to display help panel, HCUTIL00 
       o  Press PF3 twice to exit help and application panel 
       
    e) Validation for CUTIL00 ISPF 2.x Application is complete.
                                                                            
  
  
  
  
  
Enjoy CUTIL00 for MVS 3.8J!
                                                                            

======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.CUTIL00.V1R1M09.ASM 
 $ . CUTIL00     TSO CP for CLIST Variables           
 $ . CUTILTBL    CUTIL00 table processor                 
      
  - SHRABIT.CUTIL00.V1R1M09.CLIST
   . CCUTIL00    Testing harness CLIST               
   . CCUTIL0V    IVP CLIST                           

  - SHRABIT.CUTIL00.V1R1M09.CNTL
 $ . $INST00     Define Alias for HLQ CUTIL00       
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install CUTIL00 CP
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 # . $UP1109     Upgrade to V1R1M09   from   V1R1M06
   . $IVP1       IVP JCL                        
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
   . $SAMPLES    Samples JCL                    
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.CUTIL00.V1R1M09.HELP
   . CUTIL00     CUTIL00 Help member 
 $ . CCUTIL00    CCUTIL00 Help member 

  - SHRABIT.CUTIL00.V1R1M09.ISPF
 $ . CCUTIL0I    CUTIL00 ISPF CLIST
                
   . CUTIL0      CUTIL00 Message file
                
 $ . HCUTIL00    CUTIL00 Help panel
 $ . PCUTIL00    CUTIL00 ISPF panel for command line request
 # . PCUTIL01    CUTIL00 ISPF panel for MCAL and MCALA results
                
 # . TCALF01A    CUTIL00 Tutorial Panel Function 01
 # . TCALF01B    CUTIL00 Tutorial Panel Function 01 b
 # . TCALF02A    CUTIL00 Tutorial Panel Function 02
 # . TCALF02B    CUTIL00 Tutorial Panel Function 02 b
 # . TCALF03A    CUTIL00 Tutorial Panel Function 03
 # . TCALF03B    CUTIL00 Tutorial Panel Function 03 b
 # . TCALF04A    CUTIL00 Tutorial Panel Function 04
 # . TCALF04B    CUTIL00 Tutorial Panel Function 04 b
 # . TCALF07A    CUTIL00 Tutorial Panel Function 07
 # . TCALF07B    CUTIL00 Tutorial Panel Function 07 b
 # . TCALF08A    CUTIL00 Tutorial Panel Function 08
 # . TCALF08B    CUTIL00 Tutorial Panel Function 08 b
 # . TCALF09A    CUTIL00 Tutorial Panel Function 09
 # . TCALF09B    CUTIL00 Tutorial Panel Function 09 b
 # . TCALF10A    CUTIL00 Tutorial Panel Function 10
 # . TCALF10B    CUTIL00 Tutorial Panel Function 10 b
 # . TCALF11A    CUTIL00 Tutorial Panel Function 11
 # . TCALF11B    CUTIL00 Tutorial Panel Function 11 b
 # . TCALF12A    CUTIL00 Tutorial Panel Function 12
 # . TCALF12B    CUTIL00 Tutorial Panel Function 12 b
 # . TCALF13A    CUTIL00 Tutorial Panel Function 13
 # . TCALF13B    CUTIL00 Tutorial Panel Function 13 b
 # . TCALF14A    CUTIL00 Tutorial Panel Function 14
 # . TCALF14B    CUTIL00 Tutorial Panel Function 14 b
 # . TCALF15A    CUTIL00 Tutorial Panel Function 15
 # . TCALF15B    CUTIL00 Tutorial Panel Function 15 b
 # . TCALF16A    CUTIL00 Tutorial Panel Function 16
 # . TCALF16B    CUTIL00 Tutorial Panel Function 16 b
 # . TCALF17A    CUTIL00 Tutorial Panel Function 17
 # . TCALF17B    CUTIL00 Tutorial Panel Function 17 b
 # . TCALF18A    CUTIL00 Tutorial Panel Function 18
 # . TCALF18B    CUTIL00 Tutorial Panel Function 18 b
 # . TCALF19A    CUTIL00 Tutorial Panel Function 19
 # . TCALF19B    CUTIL00 Tutorial Panel Function 19 b
 # . TCALF20A    CUTIL00 Tutorial Panel Function 20
 # . TCALF20B    CUTIL00 Tutorial Panel Function 20 b
 # . TCALF21A    CUTIL00 Tutorial Panel Function 21
 # . TCALF21B    CUTIL00 Tutorial Panel Function 21 b
 # . TCALF22A    CUTIL00 Tutorial Panel Function 22
 # . TCALF22B    CUTIL00 Tutorial Panel Function 22 b
 # . TCALF22A    CUTIL00 Tutorial Panel Function 23
 # . TCALF22B    CUTIL00 Tutorial Panel Function 23 b
 # . TCALF24A    CUTIL00 Tutorial Panel Function 24
 # . TCALF24B    CUTIL00 Tutorial Panel Function 24 b
 # . TCALF25A    CUTIL00 Tutorial Panel Function 25
 # . TCALF25B    CUTIL00 Tutorial Panel Function 25 b
 # . TCALF26A    CUTIL00 Tutorial Panel Function 26
 # . TCALF26B    CUTIL00 Tutorial Panel Function 26 b
 # . TCALF27A    CUTIL00 Tutorial Panel Function 27
 # . TCALF27B    CUTIL00 Tutorial Panel Function 27 b
 # . TCALF28A    CUTIL00 Tutorial Panel Function 28
 # . TCALF28B    CUTIL00 Tutorial Panel Function 28 b
 # . TCALF29A    CUTIL00 Tutorial Panel Function 29
 # . TCALF29B    CUTIL00 Tutorial Panel Function 29 b
 # . TCALF30A    CUTIL00 Tutorial Panel Function 30
 # . TCALF30B    CUTIL00 Tutorial Panel Function 30 b
 # . TCALF31A    CUTIL00 Tutorial Panel Function 31
 # . TCALF31B    CUTIL00 Tutorial Panel Function 31 b
 # . TCALF32A    CUTIL00 Tutorial Panel Function 32
 # . TCALF32B    CUTIL00 Tutorial Panel Function 32 b
 # . TCALF32A    CUTIL00 Tutorial Panel Function 33
 # . TCALF32B    CUTIL00 Tutorial Panel Function 33 b
 # . TCALF34A    CUTIL00 Tutorial Panel Function 34
 # . TCALF34B    CUTIL00 Tutorial Panel Function 34 b
 # . TCALF35A    CUTIL00 Tutorial Panel Function 35
 # . TCALF35B    CUTIL00 Tutorial Panel Function 35 b
 # . TCALF36A    CUTIL00 Tutorial Panel Function 36
 # . TCALF36B    CUTIL00 Tutorial Panel Function 36 b
 # . TCALF37A    CUTIL00 Tutorial Panel Function 37
 # . TCALF37B    CUTIL00 Tutorial Panel Function 37 b
 # . TCALF38A    CUTIL00 Tutorial Panel Function 38
 # . TCALF38B    CUTIL00 Tutorial Panel Function 38 b
 # . TCALF39A    CUTIL00 Tutorial Panel Function 39
 # . TCALF39B    CUTIL00 Tutorial Panel Function 39 b
 # . TCALF40A    CUTIL00 Tutorial Panel Function 40
 # . TCALF40B    CUTIL00 Tutorial Panel Function 40 b
 # . TCALF41A    CUTIL00 Tutorial Panel Function 41
 # . TCALF41B    CUTIL00 Tutorial Panel Function 41 b
 # . TCALF42A    CUTIL00 Tutorial Panel Function 42
 # . TCALF42B    CUTIL00 Tutorial Panel Function 42 b
 # . TCALF42A    CUTIL00 Tutorial Panel Function 43
 # . TCALF42B    CUTIL00 Tutorial Panel Function 43 b
 # . TCALF44A    CUTIL00 Tutorial Panel Function 44
 # . TCALF44B    CUTIL00 Tutorial Panel Function 44 b
 # . TCALF45A    CUTIL00 Tutorial Panel Function 45
 # . TCALF45B    CUTIL00 Tutorial Panel Function 45 b
 # . TCALF46A    CUTIL00 Tutorial Panel Function 46
 # . TCALF46B    CUTIL00 Tutorial Panel Function 46 b
 # . TCALF47A    CUTIL00 Tutorial Panel Function 47
 # . TCALF47B    CUTIL00 Tutorial Panel Function 47 b
 # . TCALF48A    CUTIL00 Tutorial Panel Function 48
 # . TCALF48B    CUTIL00 Tutorial Panel Function 48 b
 # . TCALF49A    CUTIL00 Tutorial Panel Function 49
 # . TCALF49B    CUTIL00 Tutorial Panel Function 49 b
 # . TCALF50A    CUTIL00 Tutorial Panel Function 50
 # . TCALF50B    CUTIL00 Tutorial Panel Function 50 b
 # . TCALF51A    CUTIL00 Tutorial Panel Function 51
 # . TCALF51B    CUTIL00 Tutorial Panel Function 51 b
 # . TCALF52A    CUTIL00 Tutorial Panel Function 52
 # . TCALF52B    CUTIL00 Tutorial Panel Function 52 b
 # . TCALF52A    CUTIL00 Tutorial Panel Function 53
 # . TCALF52B    CUTIL00 Tutorial Panel Function 53 b
 # . TCALF54A    CUTIL00 Tutorial Panel Function 54
 # . TCALF54B    CUTIL00 Tutorial Panel Function 54 b
 # . TCALF55A    CUTIL00 Tutorial Panel Function 55
 # . TCALF55B    CUTIL00 Tutorial Panel Function 55 b
 # . TCALF56A    CUTIL00 Tutorial Panel Function 56
 # . TCALF56B    CUTIL00 Tutorial Panel Function 56 b
 # . TCALF57A    CUTIL00 Tutorial Panel Function 57
 # . TCALF57B    CUTIL00 Tutorial Panel Function 57 b
 # . TCALF58A    CUTIL00 Tutorial Panel Function 58
 # . TCALF58B    CUTIL00 Tutorial Panel Function 58 b
 # . TCALF59A    CUTIL00 Tutorial Panel Function 59
 # . TCALF59B    CUTIL00 Tutorial Panel Function 59 b
 # . TCALF60A    CUTIL00 Tutorial Panel Function 60
 # . TCALF60B    CUTIL00 Tutorial Panel Function 60 b
 # . TCALF61A    CUTIL00 Tutorial Panel Function 61
 # . TCALF61B    CUTIL00 Tutorial Panel Function 61 b
 # . TCALF62A    CUTIL00 Tutorial Panel Function 62
 # . TCALF62B    CUTIL00 Tutorial Panel Function 62 b
 # . TCALF62C    CUTIL00 Tutorial Panel Function 62 c
 # . TCALF63A    CUTIL00 Tutorial Panel Function 63
 # . TCALF63B    CUTIL00 Tutorial Panel Function 63 b
 # . TCALF64A    CUTIL00 Tutorial Panel Function 64
 # . TCALF64B    CUTIL00 Tutorial Panel Function 64 b
 # . TCALF65A    CUTIL00 Tutorial Panel Function 65
 # . TCALF65B    CUTIL00 Tutorial Panel Function 65 b
 # . TCALF66A    CUTIL00 Tutorial Panel Function 66
 # . TCALF66B    CUTIL00 Tutorial Panel Function 66 b
 # . TCALF67A    CUTIL00 Tutorial Panel Function 67
 # . TCALF67B    CUTIL00 Tutorial Panel Function 67 b
 # . TCALF68A    CUTIL00 Tutorial Panel Function 68
 # . TCALF68B    CUTIL00 Tutorial Panel Function 68 b
 # . TCALF69A    CUTIL00 Tutorial Panel Function 69
 # . TCALF69B    CUTIL00 Tutorial Panel Function 69 b
 # . TCALF70A    CUTIL00 Tutorial Panel Function 70
 # . TCALF70B    CUTIL00 Tutorial Panel Function 70 b
 # . TCALF70C    CUTIL00 Tutorial Panel Function 70 c
 # . TCALF71A    CUTIL00 Tutorial Panel Function 71
 # . TCALF71B    CUTIL00 Tutorial Panel Function 71 b
 # . TCALF71C    CUTIL00 Tutorial Panel Function 71 c
 # . TCALF72A    CUTIL00 Tutorial Panel Function 72
 # . TCALF72B    CUTIL00 Tutorial Panel Function 72 b
 # . TCALF73A    CUTIL00 Tutorial Panel Function 73
 # . TCALF73B    CUTIL00 Tutorial Panel Function 73 b
 # . TCALF74A    CUTIL00 Tutorial Panel Function 74
 # . TCALF74B    CUTIL00 Tutorial Panel Function 74 b
 # . TCALF75A    CUTIL00 Tutorial Panel Function 75
 # . TCALF75B    CUTIL00 Tutorial Panel Function 75 b
 # . TCALF76A    CUTIL00 Tutorial Panel Function 76
 # . TCALF76B    CUTIL00 Tutorial Panel Function 76 b
 # . TCALF77A    CUTIL00 Tutorial Panel Function 77
 # . TCALF77B    CUTIL00 Tutorial Panel Function 77 b
 # . TCALF78A    CUTIL00 Tutorial Panel Function 78
 # . TCALF78B    CUTIL00 Tutorial Panel Function 78 b
 # . TCALF79A    CUTIL00 Tutorial Panel Function 79
 # . TCALF79B    CUTIL00 Tutorial Panel Function 79 b
 # . TCALF80A    CUTIL00 Tutorial Panel Function 80
 # . TCALF80B    CUTIL00 Tutorial Panel Function 80 b
 # . TCALU001    CUTIL00 Tutorial Panel Overview
 # . TCALU002    CUTIL00 Tutorial Panel Overview
 # . TCALU003    CUTIL00 Tutorial Panel Overview
 # . TCALUA01    CUTIL00 Tutorial Panel Command Syntax
 # . TCALUA02    CUTIL00 Tutorial Panel Command Syntax
 # . TCALUA03    CUTIL00 Tutorial Panel Command Syntax
 # . TCALUB01    CUTIL00 Tutorial Panel Return Codes    
 # . TCALUB02    CUTIL00 Tutorial Panel Return Codes     
 # . TCALUB03    CUTIL00 Tutorial Panel Return Codes     
 # . TCALUB04    CUTIL00 Tutorial Panel Return Codes     
 # . TCALUC01    CUTIL00 Tutorial Panel Functions      
 # . TCALUC02    CUTIL00 Tutorial Panel Functions       
 # . TCALUC03    CUTIL00 Tutorial Panel Functions       
 # . TCALUC04    CUTIL00 Tutorial Panel Functions       
 # . TCALUC05    CUTIL00 Tutorial Panel Functions       
 # . TCALUC06    CUTIL00 Tutorial Panel Functions       
 # . TCALUC07    CUTIL00 Tutorial Panel Functions       
                
  - SHRABIT.CUTIL00.V1R1M09.MACLIB
   . README      Dummy member, this is intentional



  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




