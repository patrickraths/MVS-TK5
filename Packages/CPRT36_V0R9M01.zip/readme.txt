CPRT36 for MVS3.8J / Hercules                                               
=============================                                               


Date: 12/15/2023  Release V0R9M01
      02/10/2022  Release V0R9M00  **INITIAL software distribution
      05/13/2018  Release V0R1M00

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/CPRT36-in-MVS38J
*           Copyright (C) 2018-2023  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    CPRT36       I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    CPRT36       C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  12/15/2023 0.9.01   Larry Belmontes Jr.
*                      - Modified CPRT36 to use parm TXT instead of
*                        LOGTXT when invoking CLOGIT
*                      - Modified CPRT36 to reposition JUMP command chk
*                      - Modified CPRT36 to allow MYTUTOR command
*                      - Modified CPRT36 to check for END/RETURN/Jump
*                        after DISPLAY panel when RC=0               
*                      - Combine SYSOUT variable for batch and
*                        foreground use
*                      - Add CPRT36 tutorial
*                      - Modify msg descriptions
*
*  02/10/2022 0.9.00   Larry Belmontes Jr.                                      
*                      - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*  05/13/2018 0.1.00   Larry Belmontes Jr.
*                      - Initial prototyping with initial version
*                        of ISPF from Wally Mclaughlin
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  CPRT36.V0R9M01.HET   Hercules Emulated Tape (HET) multi-file volume
   volser=VS0901        containing software distribution library.

o  CPRT36.V0R9M01.XMI   XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.2+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   CHKDSN is a TSO utility that checks for existence of data sets
-----   and must be installed as a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/CHKDSN-in-MVS38J/

Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Note:   LISTDSJ, alias LISTDSI, is a LISTDSI-like utility that creates CLIST
-----   variables containing data set attributes and must be installed as
        a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/LISTDSJ-for-MVS-3-8J/

Note:   PRINTOFF (TSO CP) is a pre-requisite for this install
-----   and may be available on MVS3.8J TK3 and TK4- systems.          
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #325 
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/printoff.htm

Note:   PUTCARD is a utility that writes 80-byte records for SYSIN
-----   type processing and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/PUTCARD-in-MVS38J/    

Note:   CLOGIT is an ISPF add-on that performs transaction logging
-----   and must be installed as a pre-requisite.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/CLGLST-in-MVS38J/    




======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.CPRT36.V0R9M01.ASM                   PUB006     5     1 PO  FB  20  1
   SHRABIT.CPRT36.V0R9M01.CLIST                 PUB006     8     1 PO  FB  12  1
   SHRABIT.CPRT36.V0R9M01.CNTL                  PUB006    20     5 PO  FB  25  1
   SHRABIT.CPRT36.V0R9M01.HELP                  PUB006     2     1 PO  FB  50  1
   SHRABIT.CPRT36.V0R9M01.ISPF                  PUB006    10     7 PO  FB  70  1
   SHRABIT.CPRT36.V0R9M01.MACLIB                PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      47 TRKS ALLOC        16 TRKS USED       6 EXTENTS    
    
    
   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($RECVXMI)          |
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($RECVTSO)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive CPRT36 XMI',        <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.CPRT36',VRM=V0R9M01,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 CPRT36 Software Distribution                      
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,
//             UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(08,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for CPRT36 software distribution     *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE CPRT36 Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.CPRT36.V0R9M01.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(CNTL)') -  
        DA('SHRABIT.CPRT36.V0R9M01.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(HELP)') -  
        DA('SHRABIT.CPRT36.V0R9M01.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(CLIST)') -  
        DA('SHRABIT.CPRT36.V0R9M01.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(ISPF)') -  
        DA('SHRABIT.CPRT36.V0R9M01.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(ASM)') -  
        DA('SHRABIT.CPRT36.V0R9M01.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.CPRT36.V0R9M01.XMIPDS(MACLIB)') - 
        DA('SHRABIT.CPRT36.V0R9M01.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.CPRT36.V0R9M01.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer CPRT36.V0R9M01.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.CPRT36.V0R9M01.ASM
       SHRABIT.CPRT36.V0R9M01.CLIST
       SHRABIT.CPRT36.V0R9M01.CNTL
       SHRABIT.CPRT36.V0R9M01.HELP
       SHRABIT.CPRT36.V0R9M01.ISPF
       SHRABIT.CPRT36.V0R9M01.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ SHRABIT in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST00)           |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//CPRT3600 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST01)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3601 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=CPRT36,TVOLSER=VS0901,
//   HLQ='SHRABIT.CPRT36',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,
//             UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CPRT36.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST02)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3602 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=CPRT36,TVOLSER=VS0901,
//   HLQ='SHRABIT.CPRT36',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(08,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CPRT36.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($UP0901)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT360U JOB (SYS),'Upgrade CPRT36',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $UP0901  Upgrade CPRT36 Software               *
//* *       Upgrade to release V0R9M01 from V0R9M00        *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ='SHRABIT.CPRT36',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CPRT36
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=CPRT01
   SELECT MEMBER=CPRT03
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HPRT36 
   SELECT MEMBER=PPRT36 
   SELECT MEMBER=PPRT36X
   SELECT MEMBER=TPR36100 
   SELECT MEMBER=TPR36001
   SELECT MEMBER=TPR36002
   SELECT MEMBER=TPR36003
   SELECT MEMBER=TPR36004
   SELECT MEMBER=TPR36A01
   SELECT MEMBER=TPR36A02
   SELECT MEMBER=TPR36A03
   SELECT MEMBER=TPR36A04
   SELECT MEMBER=TPR36B01
   SELECT MEMBER=TPR36B02
   SELECT MEMBER=TPR36C01
   SELECT MEMBER=TPR36D01
   SELECT MEMBER=TPR36D02
   SELECT MEMBER=TPR36D03
   SELECT MEMBER=TPR36D04
   SELECT MEMBER=TPR36D05
   SELECT MEMBER=TPR36D06
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 5: $UP0901.JCL  Upgrade from previous version to V0R9M01

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading from V0R9M00, use $UP0901.JCL
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST03)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3603 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.CPRT36.V0R9M01.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.CPRT36.V0R9M01.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install CPRT36 Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST04)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3604 JOB (SYS),'Install CPRT36',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST04  Install CPRT36 Software               *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST05)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3605 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.CPRT36',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CPRT36
   SELECT MEMBER=C$CPRT36
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=CPRT00
   SELECT MEMBER=CPRT01
   SELECT MEMBER=CPRT02
   SELECT MEMBER=CPRT03
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HPRT36 
   SELECT MEMBER=PPRT36 
   SELECT MEMBER=PPRT36X
   SELECT MEMBER=TPR36100 
   SELECT MEMBER=TPR36001
   SELECT MEMBER=TPR36002
   SELECT MEMBER=TPR36003
   SELECT MEMBER=TPR36004
   SELECT MEMBER=TPR36A01
   SELECT MEMBER=TPR36A02
   SELECT MEMBER=TPR36A03
   SELECT MEMBER=TPR36A04
   SELECT MEMBER=TPR36B01
   SELECT MEMBER=TPR36B02
   SELECT MEMBER=TPR36C01
   SELECT MEMBER=TPR36D01
   SELECT MEMBER=TPR36D02
   SELECT MEMBER=TPR36D03
   SELECT MEMBER=TPR36D04
   SELECT MEMBER=TPR36D05
   SELECT MEMBER=TPR36D06
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CPRT36.V0R9M01.CNTL($INST40)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CPRT3640 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CPRT36 for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Program                       *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
//
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate CPRT36                                           |
+--------------------------------------------------------------------+
 
 
    a) Locate a sequential data set on your system,
       preferably with a few records.
 
    b) From the ISPF Main Menu, enter the following command:
 
       TSO C$CPRT36
 
    c) Press ENTER.                       
 
    d) Panel PPRT36 is displayed.
 
________________________________________________________________________________
 ------------------------  Hardcopy Utility - CPRT36  --------------------------
 Command ===>                                                           HERC01  
                                                                                
                                                                        PPRT36  
 Option ===>      J - Generate JCL to print or punch data set     
                  L - Route data set to local printer             
                                                                                
 Data Set Name ===>                                                           
   Disposition       ===>                   (KEEP or DELETE)                    
   Volume Serial     ===>                   (If not cataloged)                  
   Data Set Password ===>                   (If password protected)             
                                                                                
 SYSOUT Class     ===>    
 Local printer ID ===>                      (If option "L" selected)            
                                                                                
                                                                                
 JOB STATEMENT INFORMATION:  (If option "J", verify before proceeding)          
   ===>                                     
   ===>                                                                         
   ===>                                                                         
   ===>                                                                         
                                                                                
                                                                                
                                                                                
________________________________________________________________________________
Figure 10a: Hardcopy Utility Panel - initial display
 
    e) Referring to the above panel:
 
        1. Enter  J         in  Option
        2. Enter  your DSN  in  Data Set Name
                                (use apostrophes to fully quality)
        3. Enter  KEEP      in  Disposition
        4. Enter  A         in  SYSOUT Class
        5. Enter  JOB STATEMENT INFORMATION
        6. Press ENTER
        
    f) Panel PPRT36X is displayed acknowledging JCL generation with
       message 'CPRT030 JCL generated ...'.  See following:
 
________________________________________________________________________________
 ------------------------  Hardcopy Utility - CPRT36  --------------------------
 Command ===>                                                           HERC01  
 CPRT030  JCL generated ...                                                     
                                                                        PPRT36X 
 Option ===>      J - Generate JCL to print or punch data set     
                  L - Route data set to local printer             
                                                                                
 Data Set Name ===> 'your.data.set.PS'                                          
   Disposition       ===> KEEP              (KEEP or DELETE)                    
   Volume Serial     ===>                   (If not cataloged)                  
   Data Set Password ===>                   (If password protected)             
                                                                                
 SYSOUT Class     ===> X                       
 Local printer ID ===>                      (If option "L" selected)            
                                                                                
                                                                                
 Enter CANCEL on COMMAND line to EXIT without submitting batch request JOB(s)   
 Press END KEY to submit any generated batch request JOB(s)                     
 JOB STATEMENT INFORMATION:      
        //&SYSUID.Z JOB (SYS),'HC UTIL',    
        // CLASS=A,MSGCLASS=A,NOTIFY=&SYSUID,                                   
        // MSGLEVEL=(1,1)                                                       
        //*                                                                     
                                                                                
________________________________________________________________________________
Figure 10c: Hardcopy Utility panel - after JCL generation
 
    g) NOTE: JOB statements are now protected for the remainder of the Hardcopy
       session.
 
    h) To print the same data set locally, see the following:
 
________________________________________________________________________________
 ------------------------  Hardcopy Utility - CPRT36  --------------------------
 Command ===>                                                           HERC01  
 CPRT030  JCL generated ...                                                     
                                                                        PPRT36X 
 Option ===>      J - Generate JCL to print or punch data set     
                  L - Route data set to local printer             
                                                                                
 Data Set Name ===> 'your.data.set.PS'                                          
   Disposition       ===> KEEP              (KEEP or DELETE)                    
   Volume Serial     ===>                   (If not cataloged)                  
   Data Set Password ===>                   (If password protected)             
                                                                                
 SYSOUT Class     ===> A                       
 Local printer ID ===>                      (If option "L" selected)            
                                                                                
                                                                                
 Enter CANCEL on COMMAND line to EXIT without submitting batch request JOB(s)   
 Press END KEY to submit any generated batch request JOB(s)                     
 JOB STATEMENT INFORMATION:      
        //&SYSUID.Z JOB (SYS),'HC UTIL',    
        // CLASS=A,MSGCLASS=A,NOTIFY=&SYSUID,                                   
        // MSGLEVEL=(1,1)                                                       
        //*                                                                     
                                                                                
________________________________________________________________________________
Figure 10c: Hardcopy Utility panel - entry of Route request
 
    i) Referring to the above panel:
 
        1. Enter  L         in  Option
        2. Enter  your DSN  in  Data Set Name
                                (use apostrophes to fully quality)
        3. Enter  blanks    in  Disposition
        5. Enter  A         in  SYSOUT Class     as shown
        6. Press ENTER
        
    j) Panel PPRT36X is displayed acknowledging data set local routing with
       message 'CPRT028  Data set routed to local printer'
 
________________________________________________________________________________
 ------------------------  Hardcopy Utility - CPRT36  --------------------------
 Command ===>                                                           HERC01  
 CPRT028  Data set routed to local printer                                      
                                                                        PPRT36X 
 Option ===>      J - Generate JCL to print or punch data set     
                  L - Route data set to local printer             
                                                                                
 Data Set Name ===> 'your.data.set.PS'                                          
   Disposition       ===>                   (KEEP or DELETE)                    
   Volume Serial     ===>                   (If not cataloged)                  
   Data Set Password ===>                   (If password protected)             
                                                                                
 SYSOUT Class     ===>                        
 Local printer ID ===>                      (If option "L" selected)            
                                                                                
                                                                                
 Enter CANCEL on COMMAND line to EXIT without submitting batch request JOB(s)   
 Press END KEY to submit any generated batch request JOB(s)                     
 JOB STATEMENT INFORMATION:      
        //&SYSUID.Z JOB (SYS),'HC UTIL',    
        // CLASS=A,MSGCLASS=A,NOTIFY=&SYSUID,                                   
        // MSGLEVEL=(1,1)                                                       
        //*                                                                     
                                                                                
________________________________________________________________________________
Figure 10c: Hardcopy Utility panel - after Local routing request
 
    k) Press PF3 to submit any generated JCL for batch processing
       from the first reqeust.
 
    l) A TSO submit message is displayed near bottom of panel similar to the
       following snippet:
 
       +---------------------------------------------------------------+
       :                                                               :
       :  JOB useridZ(JOBnnnnn) SUBMITTED                              :
       :  ***                                                          :
       :                                                               :
       +---------------------------------------------------------------+
 
    m) Press ENTER.  A JCL submitted message is displayed on line 3
       similar to the following snippet:
 
       +---------------------------------------------------------------+
       :                                                               :
       :  --------------------------------  RFE DSLIST  -----------    :
       :  Command ===>                                                 :
       :  CPRT005  JCL submitted ... END key pressed                   :
       :  ' ISP.SYSCOM.ISPCLIB                    EPUB007   510   4    :
       :  ' ISP.SYSCOM.ISPCLIB.B21179.T113605      PUB007   285   2    :
       :                                                               :
       +---------------------------------------------------------------+
 
    n) Review your printer output (CLASS=A) for the two data set reports 
       representing:
 
         1- IEBGENER batch data set hardcopy
         2- PRINTOFF foreground data set hardcopy
 
    o) Validation for CPRT36 is complete.
 
 
 
+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+
 
 
    a) Congratulations!  You completed the installation for CPRT36.


+--------------------------------------------------------------------+
| Step 13. Integrate CPRT36 into UTILITY SELECTION Menu              |
+--------------------------------------------------------------------+
 
 
    a) It is suggested using the existing option 6 in the UTILITY SELECTION MENU
       (panel ISPUTILS).
                                                                     
    b) Create a copy of ISPUTILS in your application panel library
       instead of the ISPF system panel library to preserve the original
       system panel in addition to preserving your ISPUTILS changes      
       when upgrading your ISPF system with a new version.    
                                                                     
    c) Change the following line in the )BODY section for option 6 
       as shown below:                  
                                                                     
       1       10        20        30        40        50        60        70
       +---+----+----+----+----+----+----+----+----+----+----+----+----+----+
 from: ^   6 ^HARDCOPY    - Initiate hardcopy output 

   to: %   6 +HARDCOPY    - Initiate hardcopy output CPRT36
                                                                     
    d) Add the 'NEW ENTRY' line as in )PROC section as shown below 
       for option 6:

       1       10        20        30        40        50        60        70
       +---+----+----+----+----+----+----+----+----+----+----+----+----+----+
       )PROC
         &ZSEL = TRANS( TRUNC (&ZCMD,'.')
                       1,'CMD(RFE 3.1;X) NEWAPPL(ISR)'   
                       2,'CMD(RFE 3.2;X) NEWAPPL(ISR)'
                       .
                       .
       /*              6,'PGM(ISRUHC)'                           */
                       6,'CMD(%CPRT36 LOGTXN(Y)) NEWAPPL(CHCU)'  <-- NEW ENTRY
                       .
                       .
                       .
                     ' ',' '
                       *,'?' )
       )END
 
       Note:  If CLOGIT is installed, set the value of LOGTXN to Y.
       -----               Otherwise, set the value of LOGTXN to N.
 
    e) Save UTILITY SELECTION MENU panel changes.

    f) Type =3.6 in the COMMAND line and press ENTER.

    g) The new Hardcopy Utility panel should display.




Enjoy CPRT36 for ISPF 2.2 on MVS 3.8J!
                                                                            

======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.CPRT36.V0R9M01.ASM 
   . README      Dummy member, this is intentional
      
  - SHRABIT.CPRT36.V0R9M01.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.CPRT36.V0R9M01.CNTL
 $ . $INST00     Define Alias for HLQ CPRT36          
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install CPRT36 Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software                    
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 # . $UP0901     Upgrade to V0R9M01   from   V0R9M00
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.CPRT36.V0R9M01.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.CPRT36.V0R9M01.ISPF
   . C$CPRT36    CLIST to start CPRT36 from ISPF command line
 $ . CPRT36      Hardcopy Utility CLIST

   . CPRT00      CPRT00 Messages     
 $ . CPRT01      CPRT01 Messages     
   . CPRT02      CPRT02 Messages     
 $ . CPRT03      CPRT03 Messages     

 $ . HPRT36      Hardcopy Utility HELP panel
 $ . PPRT36      Hardcopy Utility panel
 $ . PPRT36X     Hardcopy Utility panel 2

     CPRT36 Tutorial Panels                  
 # . TPR36100    CPRT36 tutorial TOC         
 # . TPR36001    CPRT36 overview 1         
 # . TPR36002    CPRT36 overview 2         
 # . TPR36003    CPRT36 overview 3         
 # . TPR36004    CPRT36 overview 4         
 # . TPR36A01    CPRT36 screen description 1
 # . TPR36A02    CPRT36 screen description 2
 # . TPR36A03    CPRT36 screen description 3
 # . TPR36A04    CPRT36 screen description 4
 # . TPR36B01    CPRT36 fields description summary 1
 # . TPR36B02    CPRT36 fields description summary 2
 # . TPR36C01    CPRT36 commands 1
 # . TPR36D01    CPRT36 report snippets 1
 # . TPR36D02    CPRT36 report snippets 2
 # . TPR36D03    CPRT36 report snippets 3
 # . TPR36D04    CPRT36 report snippets 4
 # . TPR36D05    CPRT36 report snippets 5
 # . TPR36D06    CPRT36 report snippets 6
                
  - SHRABIT.CPRT36.V0R9M01.MACLIB
   . README      Dummy member, this is intentional
       
       
  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




