LUA370 - Release 1.1

This release provides a new os.vollist() function which returns a Lua
table containing DASD volume information for each volume currently mounted
in the MVS system.

A sample VOLLIST Lua script is provided in the LUA370.LUA dataset.

See the /docs/os.html for more information on the os.vollist() function.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

LUA370 - Release 1.0

LUA370 is derived from Lua 5.4.6  Copyright (C) 1994-2023 Lua.org, PUC-Rio
and built for the MVS 38J operating system.

Visit the Lua web site https://lua.org/ for more information about Lua.

The primary program in this package is the LUA member in the LUA370.LINKLIB
dataset. The LUA member can be executed in TSO as a TSO command processor
or Batch via EXEC PGM=LUA or Batch via EXEC PGM=IKJEFT01 with Lua as a
command in the SYSTSIN input.

LUA370 is also used in the HTTPD package for both configuration of HTTPD
and as a CGI program (in HTTPLUA) within the HTTPD address space.

Additional information can be found in the /docs/ directory in the 
LUA370xx.ZIP file for each release.

To install LUA370, unzip the LUA370xx.ZIP file on your PC.
- Upload the LUA370xx.XMIT file to your MVS 38J host machine using your 
  terminal emulator (LRECL=80,RECFM=FB,BLKSIZE=3200,DSORG=PS).
- Edit the INSTALL.JCL to match the name of the dataset you just uploaded.
- Submit the INSTALL.JCL to install the LUA370 package.

After you install LUA370 you should be able to enter the "LUA" command 
from the TSO READY prompt. (Read/Browse the /docs/ files for more info)

