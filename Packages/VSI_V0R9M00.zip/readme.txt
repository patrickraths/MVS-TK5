VSI for MVS3.8J / Hercules                                               
==========================                                               


Date: 11/15/2023  Release V0R9M00  **INITIAL software distribution

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/VSI-in-MVS38J
*           Copyright (C) 2023  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    VSI          I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    VSI          C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  11/15/2023 0.9.00   - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  VSI.V0R9M00.HET      Hercules Emulated Tape (HET) multi-file volume
   volser=VS0900        containing software distribution library.

o  VSI.V0R9M00.XMI      XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.2+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Note:   Generic message(s) ISRZ00x are used for error message posting
-----   by this software and must be installed as a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/ISRZ00-in-MVS38J/

Note:   VSI is a modified version of the VI tool.  VSI is rewritten for
-----   MVS 3.8J TSO CLIST and ISPF 2.2 (ISPF-like product from Wally
        Mclaughlin).

Credit: VI (REXX Exec / ISPF) is authored by Steve Kleeves (CBT File#137).
------- Enhancements were applied by other contributors. The version used
        for MVS 3.8J CLIST conversion is from File #964 by William 
        (Bill) Smith.
        Thanks to Steve and Bill for their contribution to CBT.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #137
        - or -                                                  
        https://www.cbttape.org/cbtdowns.htm  FILE #964


======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.VSI.V0R9M00.ASM                      PUB006     5     1 PO  FB  20  1
   SHRABIT.VSI.V0R9M00.CLIST                    PUB006     5     1 PO  FB  20  1
   SHRABIT.VSI.V0R9M00.CNTL                     PUB006    20     4 PO  FB  20  1
   SHRABIT.VSI.V0R9M00.HELP                     PUB006     2     1 PO  FB  50  1
   SHRABIT.VSI.V0R9M00.ISPF                     PUB006    10     2 PO  FB  20  1
   SHRABIT.VSI.V0R9M00.MACLIB                   PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      44 TRKS ALLOC        10 TRKS USED       6 EXTENTS    


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($RECVXMI)             |
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($RECVTSO)             |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive VSI XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.VSI',VRM=V0R9M00,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 VSI Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for VSI software distribution        *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE VSI Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.VSI.V0R9M00.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(CNTL)') -  
        DA('SHRABIT.VSI.V0R9M00.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(HELP)') -  
        DA('SHRABIT.VSI.V0R9M00.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(CLIST)') -  
        DA('SHRABIT.VSI.V0R9M00.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(ISPF)') -  
        DA('SHRABIT.VSI.V0R9M00.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(ASM)') -  
        DA('SHRABIT.VSI.V0R9M00.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.VSI.V0R9M00.XMIPDS(MACLIB)') - 
        DA('SHRABIT.VSI.V0R9M00.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.VSI.V0R9M00.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer VSI.V0R9M00.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.VSI.V0R9M00.ASM
       SHRABIT.VSI,V0R9M00.CLIST
       SHRABIT.VSI,V0R9M00.CNTL
       SHRABIT.VSI,V0R9M00.HELP
       SHRABIT.VSI,V0R9M00.ISPF
       SHRABIT.VSI,V0R9M00.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ VSI in MVS User Catalog               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST00)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00000 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST01)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00001 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=VSI,TVOLSER=VS0900,
//   HLQ='SHRABIT.VSI',VRM=V0R9M00,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\VSI.V0R9M00.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST02)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00002 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=VSI,TVOLSER=VS0900,
//   HLQ='SHRABIT.VSI',VRM=V0R9M00,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\VSI.V0R9M00.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($UP0900)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI0000U JOB (SYS),'Upgrade VSI',          <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *                                                      *
//* *  JOB: $UP0900  Upgrade VSI Software                  *
//* *       Upgrade to release VxRxMxx from V0R9M00        *
//* *                                                      *
//* *       - No upgrade! INITIAL distribution             *
//* -------------------------------------------------------*
//*
//UP00000  EXEC PGM=IEFBR14
//SYSPRINT DD  SYSOUT=*
// 
______________________________________________________________________
Figure 5: $UP0900.JCL  Upgrade from previous version to V0R9M00

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST03)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00003 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.VSI.V0R9M00.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.VSI.V0R9M00.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install VSI Software                                       |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST04)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00004 JOB (SYS),'Install VSI',          <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *                                                      *
//* *  JOB: $INST04  Install VSI Software                  *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST05)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00005 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.2 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.VSI',VRM=V0R9M00,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CVSI
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PVSI#1
   SELECT MEMBER=HVSI#1 
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.VSI,V0R9M00.CNTL($INST40)              |
+--------------------------------------------------------------------+


______________________________________________________________________
//VSI00040 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  VSI for MVS3.8J TSO / Hercules                      *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate VSI                                              |
+--------------------------------------------------------------------+


    a) Identify and note dataset name of a VSAM file.

    a) From the ISPF Main Menu, enter the following command:

       TSO %CVSI DSN(fully.qualified.vsam.file.name)

    b) The panel titled 'VSAM INFORMATION' is displayed.

________________________________________________________________________________
 ------------------------- VSAM DATASET INFORMATION ----------------------------
 COMMAND ===>                                                                   
                                                                                
 DATA SET NAME: LARRY01.LIM.DSXTABS.DATA                                        
    In catalog: SYS1.UCAT.TSO                                                   
      CLUSTER-- LARRY01.LIM.DSXTABS                                             
 GENERAL DATA:                               CURRENT ALLOCATION:                
    Volume serials:        PUB005               Allocated trks:    15           
    Type:                  KSDS                 Allocated extents: 1            
    Ave record length:     85                CURRENT UTILIZATION:               
    Max record length:     85                   Used trks:         15           
    Key length:            5                    Used percent:      100          
    Relative key position: 0                 USAGE DATA:                        
    CI size:               8192                 Total records:     4            
    CI freespace:          10                   Records deleted:   0            
    CA freespace:          10                   Records inserted:  1            
    1st extent CYLINDERS:  1                    Records updated:   0            
    Secondary CYLINDERS:   1                    Records retrieved: 196          
                                                CI splits:         0            
    Creation date:         06/06/2016           CA splits:         0            
    Expiration date:                            EXCP:              73           
 SHROPTNS(1,3)   RECOVERY       UNIQUE          NOERASE          INDEXED        
 NOWRITECHK      NOIMBED        NOREPLICAT      UNORDERED        NOREUSE        
 NONSPANNED                                                                     
________________________________________________________________________________
Figure 7: PVSI#1 panel with VSAM Information


    c) Press ENTER to terminate      
       - or -
       Press F1 for one page help tutorial

    d) Press ENTER to terminate, if under tutorial screen.

    e) Validation is complete.



+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!  You completed the installation for VSI.


+--------------------------------------------------------------------+
| Step 13. Integrate VSI into an ISPF Selection Menu                 |
+--------------------------------------------------------------------+


    Not applicable.






Enjoy VSI!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.VSI,V0R9M00.ASM
   . README      Dummy member, this is intentional

  - SHRABIT.VSI,V0R9M00.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.VSI,V0R9M00.CNTL
   . $INST00     Define Alias for HLQ VSI
   . $INST01     Load CNTL data set from distribution tape (HET)
   . $INST02     Load other data sets from distribution tape (HET)
   . $INST03     Install TSO Parts
   . $INST04     Install VSI Software
   . $INST05     Install ISPF Parts
   . $INST40     Install Other Software
   . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
   . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
   . $UP0900     Upgrade to V0R9M00   from   VxRxMxx
   . DSCLAIMR    Disclaimer
   . PREREQS     Required User-mods
   . README      Documentation and Installation instructions

  - SHRABIT.VSI,V0R9M00.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.VSI,V0R9M00.ISPF
   . CVSI        CLIST VSAM Information

   . PVSI#1      VSAM Information panel
   . HVSI#1      VSAM Information help panel

  - SHRABIT.VSI,V0R9M00.MACLIB
   . README      Dummy member, this is intentional


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




