PUTCARD for MVS3.8J / Hercules                                               
==============================                                               


Date: 07/01/2024  Release V0R9M01
      11/23/2022  Release V0R9M00  **INITIAL software distribution

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/PUTCARD-in-MVS38J
*           Copyright (C) 2022-2024 Larry Belmontes, Jr.


----------------------------------------------------------------------
|    PUTCARD      I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    PUTCARD      C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  07/01/2024 0.9.01   Larry Belmontes Jr.                                      
*                      - Change record delimiter from tilde to backslash
*                      - Modify program to be reenterable             
*                      - Enhance execution environment detection
*                      - Added PUTCARD Interactive test panel
*                      - Added TSO command keywords ABOUT, STAT              
*                      - Added tutorial panels                   
*                      - Added COBOL sample program
*                                                                               
*  11/23/2022 0.9.00   Larry Belmontes Jr.                                      
*                      - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  PUTCARD.V0R9M01.HET  Hercules Emulated Tape (HET) multi-file volume
   volser=VS0901        containing software distribution library.

o  PUTCARD.V0R9M01.XMI  XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/



======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.PUTCARD.V0R9M01.ASM                  PUB006     5     3 PO  FB  60  1
   SHRABIT.PUTCARD.V0R9M01.CLIST                PUB006     2     1 PO  FB  50  1
   SHRABIT.PUTCARD.V0R9M01.CNTL                 PUB006    10     3 PO  FB  30  1
   SHRABIT.PUTCARD.V0R9M01.HELP                 PUB006     2     1 PO  FB  50  1
   SHRABIT.PUTCARD.V0R9M01.ISPF                 PUB006     5     1 PO  FB  20  1
   SHRABIT.PUTCARD.V0R9M01.MACLIB               PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      26 TRKS ALLOC        10 TRKS USED       6 EXTENTS


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($RECVXMI)         |
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($RECVTSO)         |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive PUTCARD XMI',       <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 PUTCARD Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for PUTCARD software distribution    *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE PUTCARD Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.PUTCARD.V0R9M01.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(CNTL)') -  
        DA('SHRABIT.PUTCARD.V0R9M01.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(HELP)') -  
        DA('SHRABIT.PUTCARD.V0R9M01.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(CLIST)') -  
        DA('SHRABIT.PUTCARD.V0R9M01.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(ISPF)') -  
        DA('SHRABIT.PUTCARD.V0R9M01.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(ASM)') -  
        DA('SHRABIT.PUTCARD.V0R9M01.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.PUTCARD.V0R9M01.XMIPDS(MACLIB)') - 
        DA('SHRABIT.PUTCARD.V0R9M01.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.PUTCARD.V0R9M01.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer PUTCARD.V0R9M01.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.PUTCARD.V0R9M01.ASM
       SHRABIT.PUTCARD.V0R9M01.CLIST
       SHRABIT.PUTCARD.V0R9M01.CNTL
       SHRABIT.PUTCARD.V0R9M01.HELP
       SHRABIT.PUTCARD.V0R9M01.ISPF
       SHRABIT.PUTCARD.V0R9M01.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ PUTCARD in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST00)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD0 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST01)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD1 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=PUTCARD,TVOLSER=VS0901,
//   HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\PUTCARD.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST02)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD2 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=PUTCARD,TVOLSER=VS0901,
//   HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\PUTCARD.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($UP0900)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARDU JOB (SYS),'Upgrade PUTCARD',      <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $UP0901  Upgrade PUTCARD Software              *
//* *       Upgrade to release V0R9M01 from V0R9M01        *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,VIO=VIO,
//             SYSPRM='',
//             ASMPARM='NODECK,LOAD,RENT,TERM,XREF', 
//             LNKPARM='MAP,LIST,LET,RENT,XREF',
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='&ASMPARM&SYSPRM' 
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=&VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,
//             PARM='&LNKPARM',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CPUTCRDI
   SELECT MEMBER=C$PCRD01
   SELECT MEMBER=C$PCRD02
   SELECT MEMBER=C$PCRD03
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HPUTCRD
   SELECT MEMBER=PPUTCRD
   SELECT MEMBER=TPCRD100
   SELECT MEMBER=TPCRD001
   SELECT MEMBER=TPCRD002
   SELECT MEMBER=TPCRD003
   SELECT MEMBER=TPCRD004
   SELECT MEMBER=TPCRDA01
   SELECT MEMBER=TPCRDB01
   SELECT MEMBER=TPCRDC01
   SELECT MEMBER=TPCRDC02
   SELECT MEMBER=TPCRDC03
   SELECT MEMBER=TPCRDC04
   SELECT MEMBER=TPCRDC05
   SELECT MEMBER=TPCRDC06
   SELECT MEMBER=TPCRDC07
   SELECT MEMBER=TPCRDD01
   SELECT MEMBER=TPCRDD02
   SELECT MEMBER=TPCRDE01
   SELECT MEMBER=TPCRDE02
   SELECT MEMBER=TPCRDE03
   SELECT MEMBER=TPCRDF01
   SELECT MEMBER=TPCRDF02
   SELECT MEMBER=TPCRDF03
   SELECT MEMBER=TPCRDF04
   SELECT MEMBER=TPCRDF05
   SELECT MEMBER=TPCRDZ01
   SELECT MEMBER=TPCRDZ02
   SELECT MEMBER=TPCRDZ80
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit PUTCARD to SYS2.CMDLIB           *
//* -------------------------------------------------------*
//PUTCARD  EXEC  ASML,HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,MBR=PUTCARD,
//         PARM.ASM='NODECK,LOAD,TERM,XREF,RENT',
//         PARM.LKED='MAP,LIST,LET,XREF'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  If SYSn.LINKLIB or SYSn.CMDLIB is updated           *
//* *                                                      *
//* -------------------------------------------------------*
//DBSTOP   EXEC DBSTOP,
//             COND=(0,NE)               
//DBSTART  EXEC DBSTART,
//             COND=(0,NE)
// 
______________________________________________________________________
Figure 5: $UP0901.JCL  Upgrade from previous version to V0R9M01

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - V0R9M01 update from release V0R9M00
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST03)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD3 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: CMDHELP                                       *
//* *       Copy CMDPROC and SYSHELP TSO Parts             *
//* *                                                      *
//* -------------------------------------------------------*
//TSOPARTS PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             TCMDLIB='SYS2.CMDPROC',    
//             THLPLIB='SYS2.HELP'     
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TSO CLIST and SYSHELP Member Installation           *
//* *                                                      *
//* *  TSO CLIST loaded to SYS2.CMDPROC                    *
//* *  TSO HELP  loaded to SYS2.HELP                       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job.            *
//* *                                                      *
//* -------------------------------------------------------*
//TCMDHLP  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&HLQ..&VRM..CLIST,DISP=SHR             
//INHELP   DD  DSN=&HLQ..&VRM..HELP,DISP=SHR             
//OUTCLIST DD  DSN=&TCMDLIB,DISP=SHR                               
//OUTHELP  DD  DSN=&THLPLIB,DISP=SHR
//SYSIN    DD  DUMMY                                                    
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Update CMDPROC and HELP datasets                    *
//* -------------------------------------------------------*
//CMDHELP  EXEC  TSOPARTS,HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,
//         TCMDLIB='SYS2.CMDPROC',                 <--TARGET
//         THLPLIB='SYS2.HELP'                     <--TARGET
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=C$PCIVP
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install PUTCARD Software                                   |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST04)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD4 JOB (SYS),'Install PUTCARD',      <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST04  Install PUTCARD Software              *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,VIO=VIO,
//             SYSPRM='',
//             ASMPARM='NODECK,LOAD,RENT,TERM,XREF', 
//             LNKPARM='MAP,LIST,LET,RENT,XREF',
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='&ASMPARM&SYSPRM' 
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=&VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,
//             PARM='&LNKPARM',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit PUTCARD to SYS2.CMDLIB           *
//* -------------------------------------------------------*
//PUTCARD  EXEC  ASML,HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,MBR=PUTCARD,
//         PARM.ASM='NODECK,LOAD,TERM,XREF,RENT',
//         PARM.LKED='MAP,LIST,LET,XREF'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=SYS2.CMDLIB(&MBR)                  <--TARGET 
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  If SYSn.LINKLIB or SYSn.CMDLIB is updated           *
//* *                                                      *
//* -------------------------------------------------------*
//DBSTOP   EXEC DBSTOP,
//             COND=(0,NE)               
//DBSTART  EXEC DBSTART,
//             COND=(0,NE)
// 
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST05)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCARD5 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.PUTCARD',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CPUTCRDI
   SELECT MEMBER=C$PCRD01
   SELECT MEMBER=C$PCRD02
   SELECT MEMBER=C$PCRD03
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HPUTCRD
   SELECT MEMBER=PPUTCRD
   SELECT MEMBER=TPCRD100
   SELECT MEMBER=TPCRD001
   SELECT MEMBER=TPCRD002
   SELECT MEMBER=TPCRD003
   SELECT MEMBER=TPCRD004
   SELECT MEMBER=TPCRDA01
   SELECT MEMBER=TPCRDB01
   SELECT MEMBER=TPCRDC01
   SELECT MEMBER=TPCRDC02
   SELECT MEMBER=TPCRDC03
   SELECT MEMBER=TPCRDC04
   SELECT MEMBER=TPCRDC05
   SELECT MEMBER=TPCRDC06
   SELECT MEMBER=TPCRDC07
   SELECT MEMBER=TPCRDD01
   SELECT MEMBER=TPCRDD02
   SELECT MEMBER=TPCRDE01
   SELECT MEMBER=TPCRDE02
   SELECT MEMBER=TPCRDE03
   SELECT MEMBER=TPCRDF01
   SELECT MEMBER=TPCRDF02
   SELECT MEMBER=TPCRDF03
   SELECT MEMBER=TPCRDF04
   SELECT MEMBER=TPCRDF05
   SELECT MEMBER=TPCRDZ01
   SELECT MEMBER=TPCRDZ02
   SELECT MEMBER=TPCRDZ80
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL($INST40)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PUTCRD40 JOB (SYS),'Install Other Pgms',  <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate PUTCARD under TSO or TSO/ISPF                    |
+--------------------------------------------------------------------+


    a) From the ISPF Main Menu, enter the following command:

       TSO %C$PCIVP

       -- or --

       From the TSO Ready prompt, enter the following command:

       C$PCIVP

    b) The expected successful representative response is as follows:

________________________________________________________________________________

 *** C$PCIVP : PUTCARD IVP    ***
 *** ISPF IS ACTIVE           ***
 1. NO DD ALLOCATION                .  08 -->  RC=8
 2. NO DATA PASSED                  .  16 -->  RC=16
 3. NULL PARM                       .  16 -->  RC=16
 4. NULL CRDDAT                     .  16 -->  RC=16
 5. PARM DATA                       .  00 -->  RC=0
 6. CRDDAT DATA                     .  00 -->  RC=0
 7. PARM AND CRDDAT DATA, PARM WINS .  00 -->  RC=0
 8. OVERRIDE DDN W CRDDAT           .  00 -->  RC=0
 9. OVERRIDE DDN, DLM, W CRDDAT     .  00 -->  RC=0
 A. CRDDAT >80 BYTES, TRUNCATED RCD .  04 -->  RC=4
 B. CRDDAT, DLM, MULTI-RCDS WRITTEN .  00 -->  RC=0
 *** C$PCIVP : PUTCARD IVP    ***
 ***



________________________________________________________________________________
Figure 10: C$PCIVP Successful ISPF response


________________________________________________________________________________

 *** C$PCIVP : PUTCARD IVP    ***
 *** ASSUME TSO ENVIRONMENT   ***
 1. NO DD ALLOCATION                .  08 -->  RC=8
 2. NO DATA PASSED                  .  16 -->  RC=16
 3. NULL PARM                       .  16 -->  RC=16
 4. NULL CRDDAT                     .  16 -->  RC=16
 5. PARM DATA                       .  00 -->  RC=0
 6. CRDDAT DATA                     .  00 -->  RC=0
 7. PARM AND CRDDAT DATA, PARM WINS .  00 -->  RC=0
 8. OVERRIDE DDN W CRDDAT           .  00 -->  RC=0
 9. OVERRIDE DDN, DLM, W CRDDAT     .  00 -->  RC=0
 A. CRDDAT >80 BYTES, TRUNCATED RCD .  04 -->  RC=4
 B. CRDDAT, DLM, MULTI-RCDS WRITTEN .  00 -->  RC=0
 *** C$PCIVP : PUTCARD IVP    ***
 READY



________________________________________________________________________________
Figure 11: C$PCIVP Successful TSO response


    c) Review the terminal response.  The RC value should correspond
       to the value left of RC (e.g. 08 -->  RC=8).

    e) TSO or TSO/ISPF validation is complete.


+--------------------------------------------------------------------+
| Step 12. Validate PUTCARD under MVS Batch                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.PUTCARD.V0R9M01.CNTL(PCBATCH)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//PCBATCH  JOB (SYS),'PUTCARD MVS BATCH',    <-- Review and Modify           
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify 
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify 
//* -------------------------------------------------------*
//* *  PUTCARD for MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: PCBATCH                                        *
//* *       PUTCARD use sample under MVS Batch             *
//* *                                                      *
//* -------------------------------------------------------*
//*
//PCBATCHP PROC DUNIT=UNIT
//*
//*---------------------------------------
//* Pre-allocate user DSN using DD CARDS       
//* before using PUTCARD step
//*---------------------------------------
//STEP001  EXEC PGM=IEFBR14                                           
//CARDS    DD  DSN=&&TEMP,
//         DISP=(,PASS,DELETE),                                      
//         DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=80),                
//         SPACE=(CYL,(1,1)),                                         
//         UNIT=&DUNIT
//*                                                                   
//*---------------------------------------
//* Write record via PUTCARD to DD CARDS       
//*---------------------------------------
//STEP002  EXEC PGM=PUTCARD,PARM='''RCD 01\RCD 02'''
//CARDS    DD  DSN=&&TEMP,
//         DISP=(MOD,PASS,DELETE)
//*                                                                   
//*---------------------------------------
//* Print content of DD CARDS
//*---------------------------------------
//STEP003  EXEC PGM=IEBGENER,COND=(0,LT,STEP002) 
//SYSPRINT DD  SYSOUT=*                        
//SYSUT1   DD  DSN=&&TEMP, 
//         DISP=(SHR,DELETE,DELETE) 
//SYSUT2   DD  SYSOUT=*                        
//SYSIN    DD  DUMMY                           
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Validation test for PUTCARD in MVS batch            *
//* *                                                      *
//* -------------------------------------------------------*
//DOPCBAT  EXEC  PCBATCHP,
//             DUNIT=WORK                    <-- Review and Modify
//                                                                    
______________________________________________________________________
Figure 12: PCBATCH JCL


    a) Member PCBATCH runs the PUTCARD program to write sample
       records to a temporary MVS dataset.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output at your leisure.  Return codes should be 00.


+--------------------------------------------------------------------+
| Step 13. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!  You completed the installation for PUTCARD.



Enjoy PUTCARD!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.PUTCARD.V0R9M01.ASM
 $ . PUTCARD     Utility to write 80-byte records to sequential file

  - SHRABIT.PUTCARD.V0R9M01.CLIST
 $ . C$PCIVP     CLIST to invoke PUTCARD IVP under TSO/ISPF

  - SHRABIT.PUTCARD.V0R9M01.CNTL
 $ . $INST00     Define Alias for HLQ PUTCARD
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install PUTCARD Software
 $ . $INST05     Install ISPF Parts
   . $INST40     Install Other Software
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 # . $UP0901     Upgrade to V0R9M01   from   V0R9M00
 # . IVP1        TSO Batch IVP JCL
 # . IVP2        MVS Batch IVP JCL
 $ . PCBATCH     PUTCARD MVS Testing JCL
 # . ASM2PCRD    ASM   call PUTCARD Sample program
 # . COB2PCRD    COBOL call PUTCARD Sample program
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.PUTCARD.V0R9M01.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.PUTCARD.V0R9M01.ISPF

 # . CPUTCRDI    PUTCARD Interactive Driver CLIST
 # . C$PCRD01    PUTCARD Sample 1 CLIST
 # . C$PCRD02    PUTCARD Sample 2 CLIST
 # . C$PCRD03    PUTCARD Sample 3 CLIST

 # . HPUTCRD     PUTCARD Interactive Help Panel
 # . PPUTCRD     PUTCARD Interactive Panel

     PUTCARD Tutorial Panels
 # . TPCRD100    Tutorial Panel Main Menu
 # . TPCRD001    Tutorial Panel Overview 1
 # . TPCRD002    Tutorial Panel Overview 2
 # . TPCRD003    Tutorial Panel Overview 3
 # . TPCRD004    Tutorial Panel Overview 4
 # . TPCRDA01    Tutorial Panel Command Syntax 1
 # . TPCRDB01    Tutorial Panel Return Codes 1
 # . TPCRDC01    Tutorial Panel TSO Examples 1
 # . TPCRDC02    Tutorial Panel TSO Examples 2
 # . TPCRDC03    Tutorial Panel TSO Examples 3
 # . TPCRDC04    Tutorial Panel TSO Examples 4
 # . TPCRDC05    Tutorial Panel TSO Examples 5
 # . TPCRDC06    Tutorial Panel TSO Examples 6
 # . TPCRDC07    Tutorial Panel TSO Examples 7
 # . TPCRDD01    Tutorial Panel MVS Batch Examples 1
 # . TPCRDD02    Tutorial Panel MVS Batch Examples 2
 # . TPCRDE01    Tutorial Panel Interactive PUTCARD 1
 # . TPCRDE02    Tutorial Panel Interactive PUTCARD 2
 # . TPCRDE03    Tutorial Panel Interactive PUTCARD 3
 # . TPCRDF01    Tutorial Panel Calling PUTCARD 1
 # . TPCRDF02    Tutorial Panel Calling PUTCARD 2
 # . TPCRDF03    Tutorial Panel Calling PUTCARD 3
 # . TPCRDF04    Tutorial Panel Calling PUTCARD 4
 # . TPCRDF05    Tutorial Panel Calling PUTCARD 5
 # . TPCRDZ01    Tutorial Panel Change Log 1
 # . TPCRDZ02    Tutorial Panel Change Log 2
 # . TPCRDZ80    Tutorial Panel Limitations 1

  - SHRABIT.PUTCARD.V0R9M01.MACLIB
   . README      Dummy member, this is intentional


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




