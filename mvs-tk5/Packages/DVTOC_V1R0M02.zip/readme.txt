DVTOC for MVS3.8J / Hercules                                               
============================                                               


Date: 11/15/2023  Release V1R0M02
      10/09/2023  Release V1R0M01
      06/07/2023  Release V1R0M00
      02/10/2022  Release V0R9M00  **INITIAL software distribution

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/DVTOC-in-MVS38J
*           Copyright (C) 2020-2023  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    DVTOC        I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Good luck and enjoy this software as added value to MVS 3.8J!
-Larry Belmontes



----------------------------------------------------------------------
|    DVTOC        C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*
*  MM/DD/CCYY Version  Change Description
*  ---------- -------  -----------------------------------------------
*  11/15/2023 1.0.02   - Use software HLQ of SHRABIT                 
*                      - Combine DSNstr position and DSNstr into one
*                        data-entry field
*                      - Updated existing tutorial panels for combining
*                        of DSNstr  
*                      - Add LIMIT processing to VTOC DSN search
*                      - Added tutorial panels for LIMIT processing   
*
*  10/09/2023 1.0.01   - Misc documenation updates
*                      - Ignore DSNTYP for status and log recording     
*                        when blank in DVTOC                            
*                      - Add PF1 to PF Keys line and    
*                        combined UserID and PanelID on line 4
*                        for panels PDVTOCx and PDVTOKx
*                      - Correct PF5 logic error and rework            
*                        RFIND logic
*                      - Add Option CM to menu PDVTOC0  
*                      - Update msg DVTC011             
*                      - Position DVTOC for LIMIT processing
*
*  06/07/2023 1.0.00   - Add Option X  to menu PDVTOC0
*                      - Add Option /C to menu PDVTOC0  
*                      - Update panels with consistent placement of
*                        request, PFkeys, and selection codes
*                      - Check for ISPF active system
*                      - Use upgraded ISPF variables for SCRNCLK
*                      - Externalize VDEF, VGET, and VPUT to new
*                        module, DVTOCVR
*                      - Create commarea macros for DVTOCFA, DVTOCFS
*                      - Eliminate panel cursor setting
*                      - Consolidate select logic in DVTOC
*                      - Add RFIND command to DVTOC
*                      - Add MYTUTOR command to menu PDVTOC0 and DVTOC
*
*  02/10/2022 0.9.00   - Initial version released to MVS 3.8J
*                        hobbyist public domain
*
*  08/10/2020 0.5.00   Initial prototyping and development
*                      w ISPF 2.x
*
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  DVTOC.V1R0M02.HET    Hercules Emulated Tape (HET) multi-file volume
   volser=VS2000        containing software distribution library.

o  DVTOC.V1R0M02.XMI    XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.1+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   VTOC (TSO CP) is a pre-requisite for this install
-----   and is available on MVS3.8J TK3 and TK4- systems.          
        Various versions of VTOC are available from CBT website. 
        More information at:
        https://www.cbttape.org/cbtdowns.htm
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/vtoc.htm
 
Credit: TSO CP, VTOC, is authored by R. L. Miller.  
------- More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #112

Note:   PRINTOFF (TSO CP) is a pre-requisite for this install
-----   and may be available on MVS3.8J TK3 and TK4- systems.          
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #325 
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/printoff.htm

Note:   SCRATCH, CATLG, UNCATLG are pre-prequisites for this install
-----   and may be available on MVS 3.8J TK3 and TK4- systems.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  as FILE #163
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/catlg.htm
 
Credit: CATLG (TSO CP), while also supports UNCATLG and SCRATCH,
------- is authored by Dave Phillips. 
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #163
 

Note:   INSTREAM (TSO CP) is a pre-requisite for this install
-----   and may be available on MVS 3.8J TK3 and TK4- systems.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  as FILE #300
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/instream.htm
 
Credit: TSO CP, INSTREAM, originally authored by Bill Godfrey. 
------- More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #163

Note:   DELETE (TSO CP) is a pre-requisite for this install
-----   and available on MVS 3.8J TK3 and TK4- systems.

Note:   DELETE (TSO CP) is a pre-requisite for this install
-----   and available on MVS 3.8J TK3 and TK4- systems.

Note:   SHRABIT.MACLIB is macro library required to assemble/compile this
-----   software.  A version as-of this distribution is included for
        installation as a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/SHRABIT-MACLIB-in-MVS-3-8J/

Note:   GETDTE is a utility to obtain date-time-environment
-----   information and is OPTIONAL for this install.  
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/GETDTE-in-MVS38J/    

Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Note:   LISTDSJ, alias LISTDSI, is a LISTDSI-like utility that creates CLIST
-----   variables containing data set attributes and must be installed as
        a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/LISTDSJ-for-MVS-3-8J/

Note:   CLOGIT is an ISPF add-on that performs transaction logging
-----   and must be installed as a pre-requisite.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/CLGLST-in-MVS38J/    

Note:   DSCOPY is a TSO and ISPF add-on that allows copying of
-----   sequential or partitioned data sets and must be installed
        as a pre-requisite.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DSCOPY-in-MVS38J/

Note:   DFSPC is an ISPF add-on that displays volume free space information 
-----   for all non-VIO online DASD.
        OPTIONAL for this install if DFSPC will not be used.
        Typically, DFSPC is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DFSPC-in-MVS38J/    

Note:   DUCBD is an ISPF add-on that displays UCB information from 
-----   MVS 3.8J.
        OPTIONAL for this install if DUCBD will not be used.
        Typically, DUCBD is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DUCBD-in-MVS38J/

Note:   DALCDS is an ISPF add-on that displays TSO user allocation 
-----   information (DD/DSN allocations).
        OPTIONAL for this install if DALCDS will not be used.
        Typically, DALCDS is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DALCDS-in-MVS38J/

Note:   ULXL01 is an ISPF add-on (application) that displays available
-----   disk space information using three panels and one help panel.
        OPTIONAL for this install if ULXL01 will not be used.
        Typically, ULXL01 is invoked as a selection option.
        More information for enabling ULXL01 for MVS 3.8J at:
        https://www.shareabitofit.net/ULXL01-in-MVS38J/
 
Credit: ULXL01 is authored by Bill Godfrey in 1985 and later updated
------- in 1991.  Thanks to Bill for this CBT contribution. 
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #161
 

Note:   LBTUTOR is an ISPF add-on that performs tutorial dialogs
-----   and is OPTIONAL for this install if LBTUTOR will not be used.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/LBTUTOR-in-MVS38J/    

Note:   CATMGT is an ISPF add-on that provides real-time execution
-----   of IDCAMS functions to define or delete non-VSAM alias entries    
        and list catalog entries.
        OPTIONAL for this install if CATMGT will not be used.
        Typically, CATMGT is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/CATMGT-in-MVS38J/    


======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.DVTOC.V1R0M02.ASM                    PUB006    30     8 PO  FB  26  1
   SHRABIT.DVTOC.V1R0M02.CLIST                  PUB006     2     1 PO  FB  50  1
   SHRABIT.DVTOC.V1R0M02.CNTL                   PUB006    20     6 PO  FB  30  1
   SHRABIT.DVTOC.V1R0M02.HELP                   PUB006     2     1 PO  FB  50  1
   SHRABIT.DVTOC.V1R0M02.ISPF                   PUB006    25    15 PO  FB  60  1
   SHRABIT.DVTOC.V1R0M02.MACLIB                 PUB006     6     4 PO  FB  66  1
   **END**    TOTALS:      85 TRKS ALLOC        35 TRKS USED       6 EXTENTS


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($RECVXMI)           |
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($RECVTSO)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive DVTOC XMI',        <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.DVTOC',VRM=V1R0M02,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 DVTOC Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(25,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(30,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(06,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for DVTOC software distribution      *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE DVTOC Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.DVTOC.V1R0M02.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(CNTL)') -  
        DA('SHRABIT.DVTOC.V1R0M02.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(HELP)') -  
        DA('SHRABIT.DVTOC.V1R0M02.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(CLIST)') -  
        DA('SHRABIT.DVTOC.V1R0M02.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(ISPF)') -  
        DA('SHRABIT.DVTOC.V1R0M02.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(ASM)') -  
        DA('SHRABIT.DVTOC.V1R0M02.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.DVTOC.V1R0M02.XMIPDS(MACLIB)') - 
        DA('SHRABIT.DVTOC.V1R0M02.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.DVTOC.V1R0M02.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer DVTOC.V1R0M02.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.DVTOC.V1R0M02.ASM
       SHRABIT.DVTOC.V1R0M02.CLIST
       SHRABIT.DVTOC.V1R0M02.CNTL
       SHRABIT.DVTOC.V1R0M02.HELP
       SHRABIT.DVTOC.V1R0M02.ISPF
       SHRABIT.DVTOC.V1R0M02.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ SHRABIT in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST00)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC000 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC in MVS3.8J TSO / Hercules                     *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST01)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC001 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC for MVS3.8J TSO / Hercules                    *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=DVTOC,TVOLSER=VS1002,
//   HLQ='SHRABIT.DVTOC',VRM=V1R0M02,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\DVTOC.V1R0M02.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST02)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC002 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC for MVS3.8J TSO / Hercules                    *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=DVTOC,TVOLSER=VS1002,
//   HLQ='SHRABIT.DVTOC',VRM=V1R0M02,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(25,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(30,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(06,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\DVTOC.V1R0M02.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($UP1002)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC00U JOB (SYS),'Upgrade DVTOC',        <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC in MVS3.8J TSO / Hercules                     *
//* *                                                      *
//* *  JOB: $UP2000  Upgrade DVTOC software                *
//* *       Upgrade DVTOC Software from release V1R0M01    *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DVTOC to ISPLLIB                 *
//* -------------------------------------------------------*
//DVTOC    EXEC  ASML,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,MBR=DVTOC,
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)             <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PDVTOC0  
   SELECT MEMBER=HDVTOC0
   SELECT MEMBER=PDVTOCNF 
   SELECT MEMBER=TDVTC001
   SELECT MEMBER=TDVTC002
   SELECT MEMBER=TDVTC003
   SELECT MEMBER=TDVTC100
   SELECT MEMBER=TDVTCA02
   SELECT MEMBER=TDVTCA03
   SELECT MEMBER=TDVTCA04
   SELECT MEMBER=TDVTCA05
   SELECT MEMBER=TDVTCC01
   SELECT MEMBER=TDVTCC02
   SELECT MEMBER=TDVTCC03
   SELECT MEMBER=TDVTCC04
   SELECT MEMBER=TDVTCC06
   SELECT MEMBER=TDVTCC07
   SELECT MEMBER=TDVTCD01
   SELECT MEMBER=TDVTCE01
   SELECT MEMBER=TDVTCE02
   SELECT MEMBER=TDVTCE04
   SELECT MEMBER=TDVTCE05
   SELECT MEMBER=TDVTCE06
   SELECT MEMBER=TDVTCE07
   SELECT MEMBER=TDVTCE08
   SELECT MEMBER=TDVTCV01
   SELECT MEMBER=TDVTCV10
   SELECT MEMBER=TDVTCV11
   SELECT MEMBER=TDVTCV12
   SELECT MEMBER=TDVTCV13
   SELECT MEMBER=TDVTOC00
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
// 
______________________________________________________________________
Figure 5: $UP1002.JCL  Upgrade from previous version to V1R0M02

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading from V1R0M01, use $UP1002.JCL
       - Upgrading from V1R0M00, use $UP1001.JCL
       - Upgrading from V0R9M00, use $UP1000.JCL
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST03)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC003 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.DVTOC.V1R0M02.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.DVTOC.V1R0M02.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install DVTOC Software                                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST04)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC004 JOB (SYS),'Install DVTOC',        <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST04  Install DVTOC Software                *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DVTOC to ISPLLIB                 *
//* -------------------------------------------------------*
//DVTOC    EXEC  ASML,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,MBR=DVTOC,
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)              <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DVTOCFA to ISPLLIB               *
//* -------------------------------------------------------*
//DVTOCFA  EXEC  ASML,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,MBR=DVTOCFA, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)              <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DVTOCFS to ISPLLIB               *
//* -------------------------------------------------------*
//DVTOCFS  EXEC  ASML,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,MBR=DVTOCFS, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)              <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DVTOCVR to ISPLLIB               *
//* -------------------------------------------------------*
//DVTOCVR  EXEC  ASML,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,MBR=DVTOCVR, 
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)              <--TARGET 
//*
//
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST05)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC005 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC in MVS3.8J TSO / Hercules                     *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.2 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.DVTOC',VRM=V1R0M02,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=C$DVTOC      
   SELECT MEMBER=C$DVTOCB     
   SELECT MEMBER=CDVTCFL      
   SELECT MEMBER=CDVTCSEL     
   SELECT MEMBER=CDVTCSRT     
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=DVTC01 
   SELECT MEMBER=DVTC02 
   SELECT MEMBER=DVTC03 
   SELECT MEMBER=DVTC04 
   SELECT MEMBER=DVTC05 
   SELECT MEMBER=DVTC06 
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PDVTOCD  
   SELECT MEMBER=PDVTOCFA 
   SELECT MEMBER=PDVTOCI  
   SELECT MEMBER=PDVTOCR  
   SELECT MEMBER=PDVTOCNF 
   SELECT MEMBER=PDVTOC0  
   SELECT MEMBER=PDVTOC1  
   SELECT MEMBER=PDVTOC2  
   SELECT MEMBER=PDVTOC3  
   SELECT MEMBER=PDVTOC4  
   SELECT MEMBER=PDVTOC5  
   SELECT MEMBER=PDVTOK1  
   SELECT MEMBER=PDVTOK2  
   SELECT MEMBER=PDVTOK3  
   SELECT MEMBER=PDVTOK4  
   SELECT MEMBER=PDVTOK5  
   SELECT MEMBER=HDVTOC0 
   SELECT MEMBER=HDVTOCNF 
   SELECT MEMBER=HDVTOKCX 
   SELECT MEMBER=TDVTOC00    
   SELECT MEMBER=TDVTOC01   
   SELECT MEMBER=TDVTC100
   SELECT MEMBER=TDVTC001
   SELECT MEMBER=TDVTC002
   SELECT MEMBER=TDVTC003
   SELECT MEMBER=TDVTCA01
   SELECT MEMBER=TDVTCA02
   SELECT MEMBER=TDVTCA03
   SELECT MEMBER=TDVTCA04
   SELECT MEMBER=TDVTCA05
   SELECT MEMBER=TDVTCA11
   SELECT MEMBER=TDVTCB01
   SELECT MEMBER=TDVTCB02
   SELECT MEMBER=TDVTCC01
   SELECT MEMBER=TDVTCC02
   SELECT MEMBER=TDVTCC03
   SELECT MEMBER=TDVTCC04
   SELECT MEMBER=TDVTCC05
   SELECT MEMBER=TDVTCC06
   SELECT MEMBER=TDVTCC07
   SELECT MEMBER=TDVTCD01
   SELECT MEMBER=TDVTCD02
   SELECT MEMBER=TDVTCE01
   SELECT MEMBER=TDVTCE02
   SELECT MEMBER=TDVTCE03
   SELECT MEMBER=TDVTCE04
   SELECT MEMBER=TDVTCE05
   SELECT MEMBER=TDVTCE06
   SELECT MEMBER=TDVTCE07
   SELECT MEMBER=TDVTCE08
   SELECT MEMBER=TDVTCF01
   SELECT MEMBER=TDVTCF02
   SELECT MEMBER=TDVTCV01
   SELECT MEMBER=TDVTCV10
   SELECT MEMBER=TDVTCV11
   SELECT MEMBER=TDVTCV12
   SELECT MEMBER=TDVTCV13
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DVTOC.V1R0M02.CNTL($INST40)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DVTOC040 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DVTOC in MVS3.8J TSO / Hercules                     *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate DVTOC                                            |
+--------------------------------------------------------------------+

    The purpose of this step is to initiate the VTOC Utility menu
    and display a VTOC data set list with 'HERC*' partial HLQ.

    a) From the ISPF Main Menu, enter the following command:

        TSO C$DVTOC

    b) Panel PDVTOC0 is displayed.  Enter the following data,
       see Figure 9a for reference.

        1. Enter  V     for COMMAND
        2. Enter  ALL   for Volume
        3. Enter  HERC  for DSNstr
        4. Enter  N     for Limit Use
        5. Enter  space for Display Mode
        6. Enter  N     for Show no DSNs
        7. Enter  Y     for Show CAT
        8. Enter  A     for Sysout Class
        9. Press ENTER

________________________________________________________________________________
 ------------------------------  VTOC Utility  ---------------------------------
 COMMAND ===> V                                                         LARRY01

    V  - Display VTOC entries              PV - Print VTOC entries      PDVTOC0
    U  - Display Uncatalog VTOC entries    PU - Print Uncatalog VTOC entries
    /C - DVTOC Display Defaults

    F  - DASD Free Space                   D  - DASD UCB List
    DD - Display DD/DSN Allocations        X  - Disk Space Info CBT161 ULXL01
    CM - Catalog Management

 VTOC DSN Search Parameters:
    Volume       ===> ALL    Full/Prefixed Volume name or ALL
    DSNstr       ===> HERC
    Limit        Use: N KW%==> DSO    Op ==> EQ Value ==> PO

 VTOC Processing Parameters:
    Display Mode ===>        blank-ISPF B-Browse T-Terminal
    Show no DSNs ===> N      Display Results when no DSNs (Y/N)
    Show CAT     ===> Y      Show DSN Catalogued status (Y/N)
    Sysout Class ===> A      For Print requests



________________________________________________________________________________
Figure 9a: Sample PDVTOC  VTOC Utility Menu Panel

    c) Panel PDVTOK5 is displays with data set list similar to
       Figure 9b.

________________________________________________________________________________
 dd/mm/yy.jjj hh:mm       ----    VTOC Entries    --------------    ROW 1 OF 134
 COMMAND ===>                                                   SCROLL ===> PAGE

                                                             LARRY01    PDVTOK5
 VTOC ALL CAT Lvl=HERC                                       Sorted by: DSN
 PF1-Help   PF3-End   PF7-Up   PF8-Down   PF10-Left   PF11-Right
 TOTALS -   134 DATA SETS,     4820 TRKS   ALLOC,      895 TRKS   USED
  VSAM  nonVSAM    ISAM      DA      PO      PS   Other   VSrch
 00015    00119   00000   00000   00095   00020   00004   ALL

  Select Action: B BC DC D E FI P PI R SC UC CT
 S   DSN----------------------------------------- CAT VOLUME DSO ALLOC  PCT  EX
     HERC01.ACCT.OUT                              C   PUB000 PS      1  100   1
     HERC01.BRX370.EXEC                           C   PUB007 PO     45    4   1
     HERC01.CCOMPR.CNTL                           C   PUB007 PO    100    9   1
     HERC01.CHKDSN.CNTL                           C   PUB007 PO    100   32   1
     HERC01.CHKDSN2.CNTL                          C   PUB007 PO    100    5   1
     HERC01.CMDPROC                               C   MVSCAT PO     15    6   1
     HERC01.CONDENSE                              C   XMIT00 PS    579   30   1
     HERC01.EMP.DATA                              C   PUB007 PS      5   20   1
     HERC01.FPDS0001.CNTL                         C   PUB000 PS     60    3   1
     HERC01.IMREPORT                              C   TSO00A        45    0   1
     HERC01.ISP.PROF                              C   PUB000 PO     30   66   1
________________________________________________________________________________
Figure 9b: Sample PDVTOK5 VTOC Entries Panel (partial list)



    d) Use PF7/PF8 for Page Up and Page Down scrolling.

    e) Use PF10/PF11 vary the VTOC Listing View.
       Each view of the five, displays different data set attributes.
       Default view is PDVTOK5 or PDVTOC5.

    f) Select on of the data sets with a selection code of B to
       browse the data set.

    g) Use PF3 until the ISPF Main Menu is displayed.

    h) Validation for VTOC utility is complete.

    i) Provided other software is installed on your system, other DVTOC
       menu options can be exercised such as PRINT VTOC.


+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!  You completed the installation for DVTOC.


+--------------------------------------------------------------------+
| Step 13. Incorporate DVTOC into ISPF UTILITY SELECTION Menu        |
+--------------------------------------------------------------------+


    a) To integrate DVTOC into your ISPF system, refer to
       SHRABIT.DVTOC.V1R0M02.ASM(DVTOC) for suggested steps in the Overview
       section as a menu item or ISPF command.







Enjoy DVTOC for ISPF 2.x on MVS 3.8J!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.DVTOC.V1R0M02.ASM
 $ . DVTOC       TSO CP VTOC Display
   . DVTOCFA     Subroutine, Allocate/Deallocate File
   . DVTOCFS     Subroutine, DSCB-4 Volume Information
   . DVTOCVR     Subroutine, ISPF VDEFine, VGET, VPUT

  - SHRABIT.DVTOC.V1R0M02.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.DVTOC.V1R0M02.CNTL
 $ . $INST00     Define Alias for HLQ DVTOC
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install DVTOC Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 # . $UP1002     Upgrade to V1R0M02   from   V1R0M01
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.DVTOC.V1R0M02.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.DVTOC.V1R0M02.ISPF
   . C$DVTOC     IVP DVTOC          CLIST
   . C$DVTOCB    DVTOC Ext API      CLIST
   . CDVTCFL     Find/Locate        CLIST
   . CDVTCSEL    Select Processor   CLIST
   . CDVTCSRT    Sort Display       CLIST
   . DVTC01      Messages
   . DVTC02      Messages
   . DVTC03      Messages
   . DVTC04      Messages
   . DVTC05      Messages
   . DVTC06      Messages
   . PDVTOCD     VTOC Dataset Action Panel (Delete, Uncat, Catlg, Scratch)
   . PDVTOCFA    VTOC Display Dataset Attributes Panel
   . PDVTOCI     VTOC Dataset Information Panel
   . PDVTOCR     VTOC Dataset Rename Panel
 $ . PDVTOCNF    VTOC Default Config Panel
 $ . PDVTOC0     VTOC Utility Menu
   . PDVTOC1     VTOC Dataset List Panel 1 (w/Volume Summary)
   . PDVTOC2     VTOC Dataset List Panel 2 (w/Volume Summary)
   . PDVTOC3     VTOC Dataset List Panel 3 (w/Volume Summary)
   . PDVTOC4     VTOC Dataset List Panel 4 (w/Volume Summary)
   . PDVTOC5     VTOC Dataset List Panel 5 (w/Volume Summary)
   . PDVTOK1     VTOC Dataset List Panel 1
   . PDVTOK2     VTOC Dataset List Panel 2
   . PDVTOK3     VTOC Dataset List Panel 3
   . PDVTOK4     VTOC Dataset List Panel 4
   . PDVTOK5     VTOC Dataset List Panel 5
 $ . HDVTOC0     VTOC Utility Menu (HELP)
   . HDVTOCNF    VTOC Default Config Panel (HELP)
   . HDVTOKCX    VTOC Dataset List (HELP)
 $ . TDVTOC00    VTOC Utilities Tutorial Panel
   . TDVTOC01    VTOC Utilities Tutorial Panel
 $ . TDVTC100    DVTOC Tutorial Panel Main Menu
 $ . TDVTC001    DVTOC Tutorial Panel Overview
 $ . TDVTC002    DVTOC Tutorial Panel Overview
 $ . TDVTC003    DVTOC Tutorial Panel Overview
   . TDVTCA01    DVTOC Tutorial Panel Search Request
 $ . TDVTCA02    DVTOC Tutorial Panel Search Request
 # . TDVTCA03    DVTOC Tutorial Panel Search Request
 # . TDVTCA04    DVTOC Tutorial Panel Search Request
 # . TDVTCA05    DVTOC Tutorial Panel Search Request
   . TDVTCA11    DVTOC Tutorial Panel Search Request
   . TDVTCB01    DVTOC Tutorial Panel Display Defaults
   . TDVTCB02    DVTOC Tutorial Panel Display Defaults
 $ . TDVTCC01    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCC02    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCC03    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCC04    DVTOC Tutorial Panel Result Snippets
   . TDVTCC05    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCC06    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCC07    DVTOC Tutorial Panel Result Snippets
 $ . TDVTCD01    DVTOC Tutorial Panel SYSOUT Report
   . TDVTCD02    DVTOC Tutorial Panel SYSOUT Report
 $ . TDVTCE01    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE02    DVTOC Tutorial Panel Column Descriptions
   . TDVTCE03    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE04    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE05    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE06    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE07    DVTOC Tutorial Panel Column Descriptions
 $ . TDVTCE08    DVTOC Tutorial Panel Column Descriptions
   . TDVTCF01    DVTOC Tutorial Panel Selection Codes
   . TDVTCF02    DVTOC Tutorial Panel Selection Codes
 # . TDVTCV01    DVTOC Tutorial Panel Limit Operators
 # . TDVTCV10    DVTOC Tutorial Panel Limit Keywords
 # . TDVTCV11    DVTOC Tutorial Panel Limit Keywords
 # . TDVTCV12    DVTOC Tutorial Panel Limit Keywords
 # . TDVTCV13    DVTOC Tutorial Panel Limit Keywords

  - SHRABIT.DVTOC.V1R0M02.MACLIB
   . DVCTBL      Device Table Entries
   . DVTCFACA    DVTOCFA Comm Area
   . DVTCFSCA    DVTOCFS Comm Area
   . DVTCVRCA    DVTOCVR Comm Area
   . DVTCVRDT    DVTOC ISPF Var Data Fields
   . DVTCVRNL    DVTOC ISPF Var Names and Lengths
   . ISPFPL      ISPF Parameter Address List (10)
   . ISPFSRV     ISPF Service keywords
   . ISPFSRVC    ISPF Service keywords (COBOL)
   . LA#ST       Load Address and Store
   . LBISPL      Call to ISPLINK (LarryB version)
   . MISCDC      Constants for double-quotes and Apostrophe
   . MOVEC       Move VAR at R6, len reflected in R8 (requires MOVEI)
   . MOVEI       Init R6 w/ addr of VAR, init R8 to 0
   . MOVER       Move VAR at R6 until BLANK is found
   . MOVEV       Move VAR at R6
   . RDTECOMA    DateTime comm area
   . RDTECOMC    DateTime comm area (COBOL)
   . RTRIM       Remove trailing spaces
   . SVC78A      SVC78 message area


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




