CATMGT for MVS3.8J / Hercules                                               
=============================                                               


Date: 11/15/2023  Release V0R9M01
      10/01/2023  Release V0R9M00  **INITIAL software distribution

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/CATMGT-in-MVS38J
*           Copyright (C) 2023  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    CATMGT       I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    CATMGT       C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  11/15/2023 0.9.01   Larry Belmontes Jr.                                      
*                      - Add results rendering and disposition options
*                      - Expand LISTCAT option                   
*                      - Update HELP and TUTORIAL screens
*                                                                               
*  10/01/2023 0.9.00   Larry Belmontes Jr.                                      
*                      - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  CATMGT.V0R9M01.HET   Hercules Emulated Tape (HET) multi-file volume
   volser=VS0901        containing software distribution library.

o  CATMGT.V0R9M01.XMI   XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.2+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Note:   PRINTOFF (TSO CP) is a pre-requisite for this install
-----   and may be available on MVS3.8J TK3 and TK4- systems.          
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #325 
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/printoff.htm

Note:   CLOGIT is an ISPF add-on that performs transaction logging
-----   and must be installed as a pre-requisite.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/CLGLST-in-MVS38J/    

Note:   PUTCARD is a utility that writes 80-byte records for SYSIN
-----   type processing and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/PUTCARD-in-MVS38J/    



======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.CATMGT.V0R9M01.ASM                   PUB006    10     1 PO  FB  10  1
   SHRABIT.CATMGT.V0R9M01.CLIST                 PUB006     8     1 PO  FB  12  1
   SHRABIT.CATMGT.V0R9M01.CNTL                  PUB006    20     5 PO  FB  25  1
   SHRABIT.CATMGT.V0R9M01.HELP                  PUB006     2     1 PO  FB  50  1
   SHRABIT.CATMGT.V0R9M01.ISPF                  PUB006     5     4 PO  FB  80  1
   SHRABIT.CATMGT.V0R9M01.MACLIB                PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      47 TRKS ALLOC        13 TRKS USED       6 EXTENTS    


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($RECVXMI)          |
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($RECVTSO)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive CATMGT XMI',        <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.CATMGT',VRM=V0R9M01,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 CATMGT Software Distribution                      
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(08,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for CATMGT software distribution     *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE CATMGT Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.CATMGT.V0R9M01.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(CNTL)') -  
        DA('SHRABIT.CATMGT.V0R9M01.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(HELP)') -  
        DA('SHRABIT.CATMGT.V0R9M01.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(CLIST)') -  
        DA('SHRABIT.CATMGT.V0R9M01.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(ISPF)') -  
        DA('SHRABIT.CATMGT.V0R9M01.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(ASM)') -  
        DA('SHRABIT.CATMGT.V0R9M01.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.CATMGT.V0R9M01.XMIPDS(MACLIB)') - 
        DA('SHRABIT.CATMGT.V0R9M01.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.CATMGT.V0R9M01.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer CATMGT.V0R9M01.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.CATMGT.V0R9M01.ASM
       SHRABIT.CATMGT.V0R9M01.CLIST
       SHRABIT.CATMGT.V0R9M01.CNTL
       SHRABIT.CATMGT.V0R9M01.HELP
       SHRABIT.CATMGT.V0R9M01.ISPF
       SHRABIT.CATMGT.V0R9M01.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ SHRABIT in MVS User Catalog           |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST00)           |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//CATMGT00 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST01)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT01 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=CATMGT,TVOLSER=VS0901,
//   HLQ='SHRABIT.CATMGT',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CATMGT.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST02)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT02 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=CATMGT,TVOLSER=VS0901,
//   HLQ='SHRABIT.CATMGT',VRM=V0R9M01,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(08,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CATMGT.V0R9M01.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($UP0901)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT0U JOB (SYS),'Upgrade CATMGT',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $UP0901  Upgrade CATMGT Software               *
//* *       Upgrade to release V0R9M01 from V0R9M00        *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ='SHRABIT.CATMGT',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CCATMGT
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HCATMGT  
   SELECT MEMBER=PCATMGT
   SELECT MEMBER=TCMGT001
   SELECT MEMBER=TCMGT002
   SELECT MEMBER=TCMGT003
   SELECT MEMBER=TCMGTA01
   SELECT MEMBER=TCMGTA02
   SELECT MEMBER=TCMGTA03
   SELECT MEMBER=TCMGTA04
   SELECT MEMBER=TCMGTB01
   SELECT MEMBER=TCMGTB02
   SELECT MEMBER=TCMGTB03
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 5: $UP0900.JCL  Upgrade from previous version to V0R9M01

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading from V0R9M00, use $UP0901.JCL
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST03)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT03 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.CATMGT.V0R9M01.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.CATMGT.V0R9M01.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install CATMGT Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST04)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT04 JOB (SYS),'Install CATMGT',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST04  Install CATMGT Software               *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='NODECK,LOAD,RENT,TERM,XREF'
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='MAP,LIST,LET,RENT,XREF',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  Assemble Link-Edit AMSIDC                           *
//* *                                                      *
//* -------------------------------------------------------*
//AMSIDC   EXEC  ASML,HLQ='SHRABIT.CATMGT',VRM=V0R9M01,MBR=AMSIDC,
//         PARM.ASM='NODECK,LOAD,TERM,XREF',
//**       PARM.LKED='MAP,LIST,LET,XREF'
//         PARM.LKED='MAP,LIST,LET,XREF,RENT,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET 
//*
//
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST05)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT05 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.2 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.CATMGT',VRM=V0R9M01,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CCATMGT
   SELECT MEMBER=C$CATMGT
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=CMGT00
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HCATMGT
   SELECT MEMBER=PCATMGT
   SELECT MEMBER=TCMGT100
   SELECT MEMBER=TCMGT001
   SELECT MEMBER=TCMGT002
   SELECT MEMBER=TCMGT003
   SELECT MEMBER=TCMGTA01
   SELECT MEMBER=TCMGTA02
   SELECT MEMBER=TCMGTA03
   SELECT MEMBER=TCMGTA04
   SELECT MEMBER=TCMGTB01
   SELECT MEMBER=TCMGTB02
   SELECT MEMBER=TCMGTB03
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CATMGT.V0R9M01.CNTL($INST40)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CATMGT40 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CATMGT for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate CATMGT                                           |
+--------------------------------------------------------------------+


    a) From the ISPF Main Menu, enter the following command:
 
       TSO C$CATMGT
 
    b) Press ENTER.
 
    c) Panel PCATMGT is displayed.
 
________________________________________________________________________________
 --------------------------   CATALOG Management   -----------------------------
 COMMAND ===>                                                                   
 CMGT004  Invalid Selection                                                     
    I - Initialize user catalog alias                                   LARRY01 
    D - Delete user catalog alias                                       HCATMGT 
    L - LISTCAT information                                                     
                                                                                
 Results      ===> V (View/Print/Both)   Disposition  ===> D  (Keep/Delete)     
                                                                                
 Dataset Name ===>                                                              
 Level        ===> HERC01                                       (for L only)    
 CATALOG Name ===>                                              (for I or L )   
 LISTCAT Parm ===> 1     LISTCAT Data Type ===>                 (for L only)    
  1. Name (default)       1. Alias        2. Alternate Index                    
  2. History              3. Cluster      4. Data                               
  3. Volume               5. GDG          6. Index                              
  4. Allocation           7. Non-VSAM     8. Page Space                         
  5. All                  9. Path        10. User Catalog                       
                                                                                
                                                                                
 SYSOUT Class ===>                  Printer ID   ===>                           
                                                                                
                                                                                
                                                                                
________________________________________________________________________________
Figure 10a: Catalog Management Panel
 
    d) Assume the request is to list all catalog entries for HLQ HERC01 by name.
       Referring to the above panel:
 
        1. Enter  L            in  Command
        2. Enter  V            in  Results
        3. Enter  D            in  Disposition
        2. Enter  HERC01       in  Level        
        3. Enter  1            in  LISTCAT Parm
        4. Press ENTER
        
    e) A browse session will display IDCAMS results.
       See following representative snippet:
 
________________________________________________________________________________
 LARRY01.CATMGT.IDCPRT.D23279.T075532 on TSO00B ---------------- Line 1 Col 1 80
 Command ===>                                                  Scroll ===> CSR  
1       10        20        30        40        50        60        70        80
A---+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
1IDCAMS  SYSTEM SERVICES                                           TIME: 07:55:3
0                                                                               
  /* * *  IDCAMS CATALOG MANAGEMENT  * * */                                     
  /* * *  LISTCAT LEVEL              * * */                                     
  PARM GRAPHICS(CHAIN(SN))                                                      
1IDCAMS  SYSTEM SERVICES                                           TIME: 07:55:3
0IDC0001I FUNCTION COMPLETED, HIGHEST CONDITION CODE WAS 0                      
0                                                                               
  LISTCAT LEVEL(HERC01) -                                                       
  NAME                                                                          
0NONVSAM ------- HERC01.ACCT.OUT                                                
      IN-CAT --- SYS1.UCAT.TSO                                                  
0NONVSAM ------- HERC01.BRX370.EXEC                                             
      IN-CAT --- SYS1.UCAT.TSO                                                  
0NONVSAM ------- HERC01.CCOMPR.CNTL                                             
      IN-CAT --- SYS1.UCAT.TSO                                                  
0NONVSAM ------- HERC01.CHKDSN.CNTL                                             
      IN-CAT --- SYS1.UCAT.TSO                                                  
0NONVSAM ------- HERC01.CHKDSN2.CNTL                                            
      IN-CAT --- SYS1.UCAT.TSO                                        1668K FREE
________________________________________________________________________________
Figure 10c: Browse session with IDCAMS results of LISTCAT report
 
 
    f) Validation for CATMGT is complete.
 
 
 
+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+
 
 
    a) Congratulations!  You completed the installation for CATMGT.


+--------------------------------------------------------------------+
| Step 13. Integrate CATMGT into VTOC Utility Menu                   |
+--------------------------------------------------------------------+
 
 
    a) Any selection menu can be used to integrate the CATMGT function.
       It is suggested using the existing VTOC Utility menu, panel PDVTOC0.
                                                                     
    b) Add a new line in the )BODY section of panel PDVTOC0 for 
       option CM as shown below:
                                                                     
       1       10        20        30        40        50        60        70
       +---+----+----+----+----+----+----+----+----+----+----+----+----+----+
       %  ]DD%- Display DD/DSN Allocations       ]X %- Disk Space Info CBT161
 new-> %  ]CM%- Catalog Management               ]  %                   
                                                                     
    c) Add the 'NEW ENTRY' line to the )PROC section as shown below 
       for option CM:

       1       10        20        30        40        50        60        70
       +---+----+----+----+----+----+----+----+----+----+----+----+----+----+
       )PROC
         &ZSEL = TRANS(TRUNC (&ZCMD,'.')
                       F,'CMD(DFSPC) NEWAPPL(DFSP)'  
                       .
                       .
                       .
                     CM,'CMD(%CCATMGT LOGTXN(N)) NEWAPPL(CCAT)'  <-- NEW ENTRY
                     ' ',' '
                       *,'?' )
       )END
 
 
       Note: In proc CCATMGT, parm LOGTXN is set to N by defalult.
       ----- If ISPF add-on CLGLST is installed, to enable ISPF logging
             set LOGTXN to Y by using the below entry in place of
             above entry.                  
 
                     CM,'CMD(%CCATMGT LOGTXN(Y)) NEWAPPL(CCAT)'  <-- NEW ENTRY
 
 
    d) Save VTOC Utility panel changes.

    e) Redisplay the revised VTOC Utility menu, type CM in the COMMAND line
       and press ENTER.

    f) The new Catalog Management panel should display.




Enjoy CATMGT for ISPF 2.2 on MVS 3.8J!
                                                                            

======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.CATMGT.V0R9M01.ASM 
   . AMSIDC      Invoke IDCAMS with IDC* DDs
      
  - SHRABIT.CATMGT.V0R9M01.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.CATMGT.V0R9M01.CNTL
 $ . $INST00     Define Alias for HLQ CATMGT          
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install CATMGT Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software                    
 $ . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 $ . $UP0901     Upgrade to V0R9M01   from   V0R9M00 
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.CATMGT.V0R9M01.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.CATMGT.V0R9M01.ISPF
   . C$CATMGT    CLIST to start CATMGT from ISPF command line
 $ . CCATMGT     Catalog Management CLIST

   . CMGT00      CMGT00 Messages     

 $ . HCATMGT     Catalog Management HELP panel
 $ . PCATMGT     Catalog Management panel
                
     CATMGT Tutorial Panels
   . TCMGT100    Catalog Management tutorial TOC
 $ . TCMGT001    Catalog Management overview 1
 $ . TCMGT002    Catalog Management overview 2
 $ . TCMGT003    Catalog Management overview 3
 $ . TCMGTA01    Catalog Management field descriptions 1
 $ . TCMGTA02    Catalog Management field descriptions 2
 # . TCMGTA03    Catalog Management field descriptions 3
 # . TCMGTA04    Catalog Management field descriptions 4
 $ . TCMGTB01    Catalog Management action codes 1
 $ . TCMGTB02    Catalog Management action codes 2
 $ . TCMGTB03    Catalog Management action codes 3
                
  - SHRABIT.CATMGT.V0R9M01.MACLIB
   . README      Dummy member, this is intentional
       
       
  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




