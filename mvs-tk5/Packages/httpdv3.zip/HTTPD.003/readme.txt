This archive contains a HTTP Server (HTTPD) for use with MVS 38J (TK4-).

HTTP servers are used to deliver static web pages and other resources (icons, pictures, etc) to a web browesr (Chrome, Firefox, Edge, etc).

HTTP servers are also used to deliver dynamic content (think data driven pages) which we also support via LINK of external modules.  

Static documents can be stored in UFS, an emulated Unix "like" File System, or Partitioned Datasets (PDS) allocated to DD names in the HTTPD JCL that match the document extension.  An example would be index.html which you would store as member INDEX in a PDS that is allocated to the HTML DD name.

Example:
//HTML     DD DISP=SHR,DSN=HLQ.HTTPD.HTML

where HLQ is your high-level-qualifier for your datasets.  See httpd.jcl for complete sample.

The socket interface used by the HTTPD server is the DYN75 interface.  Native socket support doesn't exist in legacy MVS38J/TK4-.  If you attempt to execute the HTTPD server on some newer MVS, like z/OS, you'll likely experience S0C1 or S0C4 abends as a result.

Files in this archive:
httpd.het            Hercules Emulated Tape, vol=ser=HTTPDD
httpd.jcl            Sample JCL to execute the HTTPD server as a batch job.
httpd.proc           Sample JCL to execute the HTTPD server as a started task. Add to your SYS2.PROCLIB dataset.
loadtape.jcl         Sample JCL to load the httpd.het to SYS2.HTTPD.* datasets. <=== Do this first.
readme.txt           The file you're reading right now.

Note: The default dataset for the HTTPD steplib is SYS2.HTTPD.LINKLIB . 
You *should not* need to APF authorize this dataset if you will be running the HTTPD server as a started task. 
The HTTPD server will attempt to use SVC 244 to dynamically authorize itself at startup. 
You can add the SYS2.HTTPD.LINKLIB to the IEAAPF00 member of SYS1.PARMLIB should you so desire.

Example IEAAPF00:
 SYS1.VTAMLIB MVSRES,      
 SYS2.HTTPD.LINKLIB xxxxxx 
Be sure to replace the xxxxxx with the actual volser for the SYS2.HTTPD.LINKLIB dataset and reboot TK4- to activate the change.

To access the JES spool via the HTTPD server you should use your web browser with a url like 
http://127.0.0.1:8080/jesst.html

Once you have a JES Status page displayed you should be able to right-click on the table rows and get a context menu for the job on that table row.  The context menu has options for:
Display DD List
Download To File
View in Browser
Cancel jobname jobid
Purge jobname jobid

Sample output from the HTTPD server:
09.49.40 STC 1691  $HASP373 HTTPD    STARTED
09.49.40 STC 1691  IEF403I HTTPD - STARTED - TIME=09.49.40
09.49.40 STC 1691  HTTPD011I HTTPD was APF authorized via SVC 244
09.49.40 STC 1691  HTTPD013I STEPLIB is now APF authorized
09.49.40 STC 1691  HTTPD025I Time zone offset set to GMT -05:00:00
09.49.40 STC 1691  HTTPD032I Listening for HTTP request on port 8080
09.49.41 STC 1691  FTPD0005I Listening for FTP  request on port 8021
09.49.41 STC 1691  HTTPD046I Disk#0 File System on DD UFSDISK0 READ/WRITE
09.49.41 STC 1691  HTTPD001I Server is READY
09.49.41 STC 1691  HTTPD061I worker(13D838) TCB(9BC188) ACEE(9CCA30) TASK(166FC8) MGR(13DD48) CRT(13D5F0)
09.49.41 STC 1691  HTTPD061I worker(13D5B0) TCB(9AFCF8) ACEE(9CCA30) TASK(177FC8) MGR(13DD48) CRT(13D3E8)
09.49.41 STC 1691  HTTPD061I worker(13D3A8) TCB(9AFAA8) ACEE(9CCA30) TASK(188FC8) MGR(13DD48) CRT(13D1E0)
09.49.46 STC 1691  HTTPD061I worker(14EA88) TCB(9AF2F0) ACEE(9CCA30) TASK(1AFFC8) MGR(13DD48) CRT(152140)
09.49.46 STC 1691  HTTPD061I worker(152C48) TCB(9AEDD8) ACEE(9CCA30) TASK(1DCFC8) MGR(13DD48) CRT(13D060)
09.49.46 STC 1691  HTTPD061I worker(152508) TCB(9AEAA8) ACEE(9CCA30) TASK(1EFFC8) MGR(13DD48) CRT(152388)
10.15.53 STC 1691  HTTPD100I CONS(3) START
10.15.53 STC 1691  HTTPD100I CONS(3) STOP
10.15.53 STC 1691  HTTPD002I Server is QUIESCE
10.15.53 STC 1691  HTTPD060I socket_thread(00154FC8) shutdown
10.15.54 STC 1691  HTTPD060I worker_thread(001EFFC8) shutdown
10.15.54 STC 1691  HTTPD060I worker_thread(001DCFC8) shutdown
10.15.54 STC 1691  HTTPD060I worker_thread(001AFFC8) shutdown
10.15.54 STC 1691  HTTPD060I worker_thread(00188FC8) shutdown
10.15.54 STC 1691  HTTPD060I worker_thread(00177FC8) shutdown
10.15.55 STC 1691  HTTPD060I worker_thread(00166FC8) shutdown
10.15.56 STC 1691  HTTPD047I Terminating File System
10.15.56 STC 1691  HTTPD002I Server is SHUTDOWN
10.15.56 STC 1691  IEF404I HTTPD - ENDED - TIME=10.15.56
10.15.56 STC 1691  $HASP395 HTTPD    ENDED
