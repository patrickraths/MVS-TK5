RECVXMIT for MVS3.8J / Hercules                                               
===============================                                               


Date: 10/09/2023  Release V0R9M02
      02/21/2023  Release V0R9M01
      11/03/2021  Release V0R9M00

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/RECVXMIT-in-MVS38J
*           Copyright (C) 2021-2023  Larry Belmontes, Jr.


---------------------------------------------------------------------- 
|    RECVXMIT     I n s t a l l a t i o n   R e f e r e n c e        | 
---------------------------------------------------------------------- 

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.                         

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.
 
Good luck and enjoy this software as added value to MVS 3.8J!
-Larry Belmontes



---------------------------------------------------------------------- 
|    RECVXMIT     C h a n g e   H i s t o r y                        | 
---------------------------------------------------------------------- 
*  MM/DD/CCYY Version  Change Description
*  ---------- -------  -----------------------------------------------
*  10/09/2023 0.9.02   - Correct cross-edit of XMITIN when option
*                        2 is selected on PRECV372 panel
*                      - Update HELP panels content                 
*                      - Add MYTUTOR command to receive and transmit
*                        panels
*                      - Add tutorial panels
*
*  02/21/2023 0.9.01   - Support mixed-case for PC and DEVINIT
*                        filenames
*                      - Correction to PUTCARD command syntax and  
*                        comments
*                      - Removed utilities, CUTIL00 and PUTCARD, from
*                        distribution as both utilities will be
*                        maintained separately
*                      - New PUTCARD utility must be downloaded and  
*                        and installed for support of mixed-case, 
*                        see README file for more information     
*
*  11/03/2021 0.9.00   - Initial version released to MVS 3.8J
*                        hobbyist public domain
*
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ RECVXMIT in Master Catalog
 
o  $INST01.JCL          Load CNTL data set from distribution tape
 
o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs                  
 
o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs                  
 
o  RECVXMIT.V0R9M02.HET Hercules Emulated Tape (HET) multi-file volume
                        with VOLSER of VS0902 containing software
                        distribution.
 
o  RECVXMIT.V0R9M02.XMI XMIT file containing software distribution.   
 
o  DSCLAIMR.TXT         Disclaimer
 
o  PREREQS.TXT          Required user-mods 
 
o  README.TXT           This File                                              
 
 
Note:   ISPF v2.1+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.
 
Note:   PUTCARD is a utility that writes 80-byte records for SYSIN
-----   type processing and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/PUTCARD-in-MVS38J/    
       
Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Credit: RECV370 and XMIT370 are pre-requisites for this install
------- and available on some MVS3.8J TK3 and TK4- systems.          
        RECV/XMIT software (by Jim Morrison) is available on CBT File 571.
        Thanks to Jim Morrison for his CBT contribution.
        More information at:
        https://www.cbttape.org/cbtdowns.htm               
       
       
======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog password may be required for some installation
   steps. 
 
o  If loading via tape files, device 480 is utilized.
 
o  Below is a DATASET List after tape distribution load for reference purposes:
    
   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   RECVXMIT.V0R9M02.ASM                         PUB006     5     1 PO  FB  20  1
   RECVXMIT.V0R9M02.CLIST                       PUB006     2     1 PO  FB  50  1
   RECVXMIT.V0R9M02.CNTL                        PUB006    20     4 PO  FB  20  1
   RECVXMIT.V0R9M02.HELP                        PUB006     2     1 PO  FB  50  1
   RECVXMIT.V0R9M02.ISPF                        PUB006    15     4 PO  FB  26  1
   RECVXMIT.V0R9M02.MACLIB                      PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      46 TRKS ALLOC        12 TRKS USED       6 EXTENTS    
    
   Confirm the TOTAL track allocation is available on your device.
    
   Note: A different DASD device type may be used to yield
         different usage results.
 
o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,  
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.
 
o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.
    
   //         USER=???????,PASSWORD=????????
 
o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or 
   ISPPLIB (Panel) libraries.
 
o  Download ZIP file to your PC local drive.    

o  Unzip the downloaded file into a temp directory on your PC device.
 
o  Install pre-requisite (if any) software and/or user modifications.
 
o  JCL from you local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/
 
 
                                                
======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================
                                                
+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+
 
 
    a) Software can be installed from two sources, HET or XMI.    
          
       - For tape installation (HET), proceed to STEP 3. ****     
          
         or
          
       - For XMIT installation (XMI), proceed to next STEP.     
 
 
+--------------------------------------------------------------------+
| Step 2. Load XMIPDS data set from XMI SEQ file                     |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($RECVXMI)                |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECV000A JOB (SYS),'Receive RECVXMIT XMI',     <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ=RECVXMIT,VRM=V0R9M02,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//STEPLIB  DD  DSN=SYS2.LINKLIB,DISP=SHR         <-- Review and Modify
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(CATMGT) 

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(CATMGT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//* -------------------------------------------------------*
//* RECV370 XMIPDS TEMP                                       
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//* -------------------------------------------------------*
//* RECV370 CNTL, HELP, CLIST, ISPF, ASM, MACLIB
//* -------------------------------------------------------*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//HELP     EXEC RECV,TYP=HELP                             
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//CLIST    EXEC RECV,TYP=CLIST                            
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//ISPF     EXEC RECV,TYP=ISPF                             
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,05,10)),
//             DISP=&DDISP   
//ASM      EXEC RECV,TYP=ASM                              
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP   
//MACLIB   EXEC RECV,TYP=MACLIB                           
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL
 
 
______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for RECVXMIT software distribution   *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure RECVXMIT HLQ alias is defined
//*        on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, and 
//*    NOPRompt parms.                                              
//*
//*    The target volume during the RECEIVE action will be at
//*    systems discretion.     
//*
//*    If a desired volume is required, append the Volser(volser)
//*    parm to the affected RECEIVE commands below. 
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(RECVXMIT) 

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(RECVXMIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//* -------------------------------------------------------*
//* TSO RECEIVE CNTL, HELP, CLIST, ISPF, ASM, MACLIB 
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'your.transfer.xmi' with   */    
 /* actual transferred XMI SEQ DSN    */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('RECVXMIT.V0R9M02.XMIPDS') NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(CNTL)')   -  
        DA('RECVXMIT.V0R9M02.CNTL')   NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(HELP)')   -  
        DA('RECVXMIT.V0R9M02.HELP')   NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(CLIST)')  -  
        DA('RECVXMIT.V0R9M02.CLIST')  NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(ISPF)')   -  
        DA('RECVXMIT.V0R9M02.ISPF')   NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(ASM)')    -  
        DA('RECVXMIT.V0R9M02.ASM')    NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('RECVXMIT.V0R9M02.XMIPDS(MACLIB)') -  
        DA('RECVXMIT.V0R9M02.MACLIB') NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'RECVXMIT.V0R9M02.XMIPDS'                
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL
 
 
    a) Transfer RECVXMIT.V0R9M02.XMI to MVS using your 3270 emulator.
       
       Make note of the DSN assigned on MVS transfer.       
       
       Use transfer IND$FILE options:                   
       
          NEW BLKSIZE=3200 LRECL=80 RECFM=FB     
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)
             
       Ensure the DSN on MVS exists with the correct DCB information:
       
          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB     
       
          
    b) If using RECV370 to load XMI, 
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB 
       statement to conform to your installation standard.
          
          - or -
          
       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation 
       including the DSN assigned during the transfer above for
       the XMI file.
 
    d) Submit the job.                                              
 
    e) Review job output for successful load of the following PDSs:
 
       RECVXMIT.V0R9M02.ASM   
       RECVXMIT.V0R9M02.CLIST 
       RECVXMIT.V0R9M02.CNTL  
       RECVXMIT.V0R9M02.HELP  
       RECVXMIT.V0R9M02.ISPF  
       RECVXMIT.V0R9M02.MACLIB
 
    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.
 
    g) Proceed to STEP 6.   ****
 
 
+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ RECVXMIT in MVS User Catalog          |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST00)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMIT JOB (SYS),'Def RECVXMIT Alias',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT in MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST00  Define Alias for HLQ RECVXMIT         *
//* *  Note: The master catalog password will be required  *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(RECVXMIT) 

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(RECVXMIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL
 
 
    a) Copy and paste the above JCL to a PDS member, update JOB 
       statement to conform to your installation standard.             
 
    b) Submit the job.                                  
 
    c) Review job output for successful DEFINE ALIAS.
 
    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function 
          completing with condition code of 0.
           
    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS 
          function being bypassed.
           
 
+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST01)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMI1 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT in MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC HLQ=RECVXMIT,VRM=V0R9M02,TVOLSER=VS0902,      
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&HLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL
 
 
    a) Before submitting the above job, the distribution tape   
       must be made available to MVS by issuing the following
       command from the Hercules console:
 
       DEVINIT 480 X:\dirname\RECVXMIT.V0R9M02.HET READONLY=1
 
       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file. 
 
    b) Issue the following command from the MVS console to vary
       device 480 online:
 
       V 480,ONLINE
 
    c) Copy and paste the above JCL to a PDS member, update JOB 
       statement to conform to your installation standard.
 
       Review JCL and apply any modifications per your installation.
 
    d) Submit the job.                                              
 
    e) Review job output for successful load of the CNTL data set.
 
    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.
 
 
+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST02)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMI2 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT in MVS3.8J TSO / Hercules                  *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC HLQ=RECVXMIT,VRM=V0R9M02,TVOLSER=VS0902,            
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&HLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&HLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&HLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&HLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&HLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(15,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//                                                                  
______________________________________________________________________
Figure 4: $INST02 JCL
 
 
    a) Member $INST02 installs remaining data sets from distribution
       tape.                                 
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Before submitting the above job, the distribution tape   
       must be made available to MVS by issuing the following
       command from the Hercules console:
 
       DEVINIT 480 X:\dirname\RECVXMIT.V0R9M02.HET READONLY=1
 
       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file. 
 
    d) Issue the following command from the MVS console to vary
       device 480 online:
 
       V 480,ONLINE
 
    e) Submit the job.
 
    f) Review job output for successful loads.  
 
 
+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($UP0901)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMTU JOB (SYS),'Upgrade RECVXMIT',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT for MVS3.8J TSO / Hercules                 *
//* *                                                      *
//* *  JOB: $UP0902                                        *
//* *       Upgrade RECVXMIT Software from release V0R9M01 *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ=RECVXMIT,VRM=V0R9M02,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PRECV372 
   SELECT MEMBER=HRECV372 
   SELECT MEMBER=PXMIT372 
   SELECT MEMBER=HXMIT372 
   SELECT MEMBER=PRXCNFG  
   SELECT MEMBER=HRXCNFG  
   SELECT MEMBER=TXMIT100 
   SELECT MEMBER=TXMIT001 
   SELECT MEMBER=TXMIT002 
   SELECT MEMBER=TXMITA01 
   SELECT MEMBER=TXMITA02 
   SELECT MEMBER=TXMITA03 
   SELECT MEMBER=TXMITA04 
   SELECT MEMBER=TXMITA05 
   SELECT MEMBER=TXMITA06 
   SELECT MEMBER=TXMITB01 
   SELECT MEMBER=TXMITB02 
   SELECT MEMBER=TXMITB03 
   SELECT MEMBER=TXMITB04 
   SELECT MEMBER=TXMITB05 
   SELECT MEMBER=TXMITB06 
   SELECT MEMBER=TXMITB07 
   SELECT MEMBER=TXMITC01 
   SELECT MEMBER=TXMITC02 
   SELECT MEMBER=TXMITC03 
   SELECT MEMBER=TXMITC04 
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
// 
______________________________________________________________________
Figure 5: $UP0902.JCL  Upgrade from previous version to V0R9M02
 
    a) If this is the INITIAL software distribution, proceed to STEP 7.
 
    b) This software may be installed in FULL or UPGRADE from a
       prior version.
 
    Note:  If the installed software version is NOT the most recent 
    -----  PREVIOUS version, perform a FULL install.
 
    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.
 
           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.
 
    Note:  $UPvrmm.JCL members exist in each software version.      
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.
 
    c) If a FULL install of this software distribution is elected   
       regardless of previous version installed on your system,
       proceed to STEP 7.
 
    d) If this is an UPGRADE from the PREVIOUS version,       
       execute the below JCL based on current installed version:  
 
       - $UP0902 JCL to update from V0R9M01 to V0R9M02
       - $UP0901 JCL to update from V0R9M00 to V0R9M01
       - V0R9M00 is initial release, thus, no updates available!
 
    e) After upgrade is applied, proceed to validation, STEP 11.
 
 
+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST03)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMI3 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT in MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=RECVXMIT.V0R9M02.CLIST,DISP=SHR            
//INHELP   DD  DSN=RECVXMIT.V0R9M02.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=C$RCV372
    SELECT MEMBER=C$XMI372
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL
 
 
    a) Member $INST03 installs TSO component(s).
 
       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Submit the job.
 
    d) Review job output for successful load(s).
 
 
+--------------------------------------------------------------------+
| Step 8. Install RECVXMIT Software                                  |  
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST04)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMI4 JOB (SYS),'Install RECVXMIT',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT for MVS3.8J TSO / Hercules                 *
//* *                                                      *
//* *  JOB: $INST04  Install RECVXMIT Software             *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
//
______________________________________________________________________
Figure 7: $INST04 JCL
 
 
    a) Member $INST04 installs program(s).
 
       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Submit the job.
 
    d) Review job output for successful completion.
 
 
+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST05)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXMI5 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT in MVS3.8J TSO / Hercules                  *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ=RECVXMIT,VRM=V0R9M02,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CRECV372
   SELECT MEMBER=CXMIT372 
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=PXMI00 
   SELECT MEMBER=PXMI01 
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PRECV372 
   SELECT MEMBER=HRECV372 
   SELECT MEMBER=PXMIT372 
   SELECT MEMBER=HXMIT372 
   SELECT MEMBER=PRXCNFG  
   SELECT MEMBER=HRXCNFG  
   SELECT MEMBER=TXMIT100 
   SELECT MEMBER=TXMIT001 
   SELECT MEMBER=TXMIT002 
   SELECT MEMBER=TXMITA01 
   SELECT MEMBER=TXMITA02 
   SELECT MEMBER=TXMITA03 
   SELECT MEMBER=TXMITA04 
   SELECT MEMBER=TXMITA05 
   SELECT MEMBER=TXMITA06 
   SELECT MEMBER=TXMITB01 
   SELECT MEMBER=TXMITB02 
   SELECT MEMBER=TXMITB03 
   SELECT MEMBER=TXMITB04 
   SELECT MEMBER=TXMITB05 
   SELECT MEMBER=TXMITB06 
   SELECT MEMBER=TXMITB07 
   SELECT MEMBER=TXMITC01 
   SELECT MEMBER=TXMITC02 
   SELECT MEMBER=TXMITC03 
   SELECT MEMBER=TXMITC04 
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL
 
 
    a) Member $INST05 installs ISPF component(s).
 
       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names. 
       The DD statements are tagged with '<--TARGET'.
 
    d) Submit the job.
 
    e) Review job output for successful load(s).
 
 
+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |  
+--------------------------------------------------------------------+
|         JCL Member: RECVXMIT.V0R9M02.CNTL($INST40)                 |
+--------------------------------------------------------------------+
 
 
______________________________________________________________________
//RECVXM40 JOB (SYS),'Install Other Pgms',   <-- Review and Modify 
//             CLASS=A,                      <-- Review and Modify
//             MSGCLASS=X,                   <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID <-- Review and Modify
//* -------------------------------------------------------*
//* *  RECVXMIT for MVS3.8J TSO / Hercules                 *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *                                                      *
//* *       PUTCARD resides in the ISPLLIB library per     *
//* *       the V0R9M00 installation.                      *
//* *                                                      *
//* *       Rename old PUTCARD utility to PUTCARDO to      *
//* *       isolate future maintenance of PUTCARD.         *
//* *                                                      *
//* *       PUTCARDO is not used but may be deleted        *
//* *       manually at users discretion.                  *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Change XXXXXXXX to your ISPF LLIB Library       *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//STEP01   EXEC PGM=IDCAMS
//SYSPRINT DD  SYSOUT=*
//DD1      DD  DSN=XXXXXXXX.ISPLLIB,               
//             DISP=SHR
//SYSIN   DD  *
  ALTER          XXXXXXXX.ISPLLIB(PUTCARD) -
         NEWNAME (XXXXXXXX.ISPLLIB(PUTCARDO)) -
         FILE(DD1)
//
  DELETE  XXXXXXXX.ISPLLIB(PUTCARD) FILE(DD1) 
______________________________________________________________________
Figure 9: $INST40 JCL
 
 
    a) Member $INST40 installs additional software.
 
       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.
 
    b) Review and update JOB statement and other JCL to conform to your
       installation standard.                                       
 
    c) Submit the job.
 
    d) Review job output for successful completion.
 
 
+--------------------------------------------------------------------+
| Step 11. Configure and Sample RECVXMIT                             |
+--------------------------------------------------------------------+
 
    The purpose of this step is to configure RECVXMIT base variables
    and test the RECEIVE function to receive an XMI MVS file and 
    create a MVS PDS. Refer to Figures 10a and 10b below.
 
 
    a) Locate the DSN of an XMI MVS file on your legacy system.
 
    b) From the ISPF Main Menu, enter the following command:    
       TSO %C$RCV372                                                   
 
    c) The panel PRECV372 is displayed.                                  
 
    d) Type "/C" in the COMMAND line and press ENTER.                    
 
    e) The panel PRXCNFG is displayed.                                  
     
       1. Review the displayed default values. 
       2. Make desired changes per your installation.
          e.g.  STEPLIBs, PROGRAM NAMES, etc. 
       3. When complete, type SAVE in the COMMAND line and press ENTER 
          to save configuration.
       4. Press PF3 to return to panel PRECV372.
 
    f) This validation will test RECV370 by receiving an MVS XMIT file
       to a PDS file.          
 
        1. Enter  1 in OPTION line       
        2. Enter DSN for XMIT MVSFILE    
        2. Enter DSN for MVS Output File 
           including UNIT, VOL, SPACE, and DISP        
        2. Enter JOB STATEMENTS (up to 4) per your installation
        5. Press ENTER
        5. Job submission message is displayed for batch job
        6. Review batch job for successful execution 
        
    g) Validation for RECVXMIT is complete.
 
 
 
________________________________________________________________________________
 --------------------   Receive XMIT File   ------------------------------------
 OPTION  ===> 1                                                                 
                                                                                
  1  Receive XMIT file on MVS to PDS/SEQ file                           LARRY03 
  2  Receive XMIT file on PC  to PDS/SEQ file                           PRECV372
                                                                        PXMI    
  XMIT Input File                                                               
 1 MVSFILE: your.mvs.xmi.file.here                                              
 -or-                                                                           
 2 PCFILE: M:\MVS38J\TEMP\your.host.xmi.file.here                               
   Reader Control for PCFILE                                                    
    HercRDR Jes2RDR DEVINIT Reset Command                                       
    20C     RDR3    M:/MVS38J/JCL/DUMMY EOF                                     
                                                                                
  MVS Output File                                                               
   DSN: your.mvs.pds.or.seq.file.here                VOL: vvvvvvv UNIT: uuuuuuuu
   SPACE: (TRK,(60,10),RLSE)          DISP: (,CATLG,DELETE)                     
                                                                                
  JOB STATEMENT INFORMATION                                                     
   ===> //RECV370A JOB (SYS),'RECV XMI',REGION=0M,                              
   ===> //   CLASS=A,MSGCLASS=A,MSGLEVEL=(1,1),                                 
   ===> //   COND=(0,NE),NOTIFY=&SYSUID                                         
   ===> //* NEW                                                                 
________________________________________________________________________________
Figure 10a: Sample PRECV372 Receive Panel            
 
 
 

________________________________________________________________________________
 --------------------   Receive Transmit Configuration   -----------------------
 OPTION  ===>                                                                   
                                                                                
     Type SAVE and press ENTER to save values                           LARRY03 
                                                                        PRXCNFG 
                                                                        PXMI    
  RECV370 XMIT370 Parameters                                                    
   RECV370 STEPLIB:                                                             
   XMIT370 STEPLIB:                                                             
    OSCMD  Program: BSPOSCMD                                                    
   HercCMD Program: BSPHRCMD                                                    
     Delay Program: BSPDELAY                                                    
     Delay Seconds: 0        (0-20 seconds)                                     
   Delete Temp JCL: Y        (Y/N)                                              
       SYSUTx Unit: 3390     (e.g.  3390,SYSDA,etc.)                            
      SYSUTx Space: (CYL,(100,50))                                              
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
    PF1 Help       PF3 Return       PF4 End                                     
________________________________________________________________________________
Figure 10b: Sample PRXCNFG Configuration Panel       
 
 
 
+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+
 
 
    a) Congratulations!  You completed the installation for RECVXMIT.


+--------------------------------------------------------------------+
| Step 13. Incorporate RECVXMIT into ISPF UTILITY SELECTION Menu     |
+--------------------------------------------------------------------+
 
 
    a) It is suggested using options RECV and XMIT from the UTILITY 
       SELECTION MENU (panel ISPUTILS) as option 3.RECV and 3.XMIT.             
                                                                     
    b) Create a copy of ISPUTILS in your application panel library
       instead of the ISPF system panel library to preserve the original
       system panel in addition to preserving your ISPUTILS changes      
       when upgrading your ISPF system with a new version.    
                                                                     
    c) Add the 'NEW ENTRY' line as shown below after option 9 as 
       new menu options:
    
     %   9 +COMMANDS    - Create/change an application command table  
     %RECV +RECEIVE     - Receive  XMI file to MVS       <-- NEW ENTRY
     %XMIT +TRANSMIT    - Transmit MVS file to XMI       <-- NEW ENTRY
                             
    d) Add the 'NEW ENTRY' lines as shown below:
                                                                          
       )PROC
         &ZSEL = TRANS( TRUNC (&ZCMD,'.')
                       1,'CMD(RFE 3.1;X) NEWAPPL(ISR)'   
                       .
                       .
                       9,'PANEL(ISPUCMA)' 
                    RECV,'PANEL(PRECV372) NEWAPPL(PXMI)'     <-- NEW ENTRY
                    XMIT,'PANEL(PXMIT372) NEWAPPL(PXMI)'     <-- NEW ENTRY
                       .
                       .
                     ' ',' '
                       *,'?' )
       )END
 
    e) Save UTILITY SELECTION MENU panel changes.                               
                                                                           
    f) Type =3 in the COMMAND line.  The new menu items (RECV and XMIT) 
       should display. 

    g) Type RECV in the COMMAND line.  The new RECEIVE menu (panel PRECV372) 
       should display.

    h) Type =3 in the COMMAND line.

    g) Type XMIT in the COMMAND line.  The new TRANSMIT menu (panel PXMIT372) 
       should display.



Enjoy RECVXMIT for ISPF 2.x on MVS 3.8J!
                                                                            

======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - RECVXMIT.V0R9M02.ASM 
   . README      Dummy member, this is intentional

  - RECVXMIT.V0R9M02.CLIST
   . C$RCV372    TSO CLIST to start ISPF Receive Dialog
   . C$XMI372    TSO CLIST to start ISPF Transmit Dialog

  - RECVXMIT.V1R1M02.CNTL
 $ . $INST00     Define Alias for HLQ RECVXMIT       
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install RECVXMIT Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 $ . $UP0902     Upgrade to V0R9M02   from   V0R9M01
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - RECVXMIT.V0R9M02.HELP
   . README      Dummy member, this is intentional

  - RECVXMIT.V0R9M02.ISPF
   . CRECV372    Receive  CLIST
   . CXMIT372    Transmit CLIST

   . PXMI00      Messages     
   . PXMI01      Messages     

 $ . HRECV372    Receive Help Panel
 $ . HRXCNFG     Configuration Help Panel
 $ . HXMIT372    Transmit Help Panel
 $ . PRECV372    Receive Panel
 $ . PRXCNFG     Configuration Panel
 $ . PXMIT372    Transmit Panel

     RECVXMIT Tutorial Panels
 # . TXMIT100    Receive Transmit tutorial TOC
 # . TXMIT001    Receive Transmit overview 1
 # . TXMIT002    Receive Transmit overview 1
 # . TXMITA01    Receive XMI 1 
 # . TXMITA02    Receive XMI 2
 # . TXMITA03    Receive XMI 3
 # . TXMITA04    Receive XMI 4
 # . TXMITA05    Receive XMI 5
 # . TXMITA06    Receive XMI 6
 # . TXMITB01    Transmit XMI 1
 # . TXMITB02    Transmit XMI 2
 # . TXMITB03    Transmit XMI 3
 # . TXMITB04    Transmit XMI 4
 # . TXMITB05    Transmit XMI 5
 # . TXMITB06    Transmit XMI 6
 # . TXMITB07    Transmit XMI 7
 # . TXMITC01    Config Default values 1
 # . TXMITC02    Config Default values 2
 # . TXMITC03    Config Default values 3
 # . TXMITC04    Config Default values 4

  - RECVXMIT.V0R9M02.MACLIB
   . README      Dummy member, this is intentional



  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation. 
       
       
 $ - Denotes modified software component for THIS DISTRIBUTION               
     relative to prior DISTRIBUTION               
       
 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION               
       
       
       
       
